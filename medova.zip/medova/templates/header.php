<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }

    if( class_exists( 'ReduxFramework' ) && defined('ELEMENTOR_VERSION') ) {
        if( is_page() || is_page_template('template-builder.php') ) {
            $medova_post_id = get_the_ID();

            // Get the page settings manager
            $medova_page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

            // Get the settings model for current post
            $medova_page_settings_model = $medova_page_settings_manager->get_model( $medova_post_id );

            // Retrieve the color we added before
            $medova_header_style = $medova_page_settings_model->get_settings( 'medova_header_style' );
            $medova_header_builder_option = $medova_page_settings_model->get_settings( 'medova_header_builder_option' );

            if( $medova_header_style == 'header_builder'  ) {

                if( !empty( $medova_header_builder_option ) ) {
                    $medovaheader = get_post( $medova_header_builder_option );
                    echo '<header class="header">';
                        echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $medovaheader->ID );
                    echo '</header>';
                }
            } else {
                // global options
                $medova_header_builder_trigger = medova_opt('medova_header_options');
                if( $medova_header_builder_trigger == '2' ) {
                    echo '<header>';
                    $medova_global_header_select = get_post( medova_opt( 'medova_header_select_options' ) );
                    $header_post = get_post( $medova_global_header_select );
                    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $header_post->ID );
                    echo '</header>';
                } else {
                    // wordpress Header
                    medova_global_header_option();
                }
            }
        } else {
            $medova_header_options = medova_opt('medova_header_options');
            if( $medova_header_options == '1' ) {
                medova_global_header_option();
            } else {
                $medova_header_select_options = medova_opt('medova_header_select_options');
                $medovaheader = get_post( $medova_header_select_options );
                echo '<header class="header">';
                    echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $medovaheader->ID );
                echo '</header>';
            }
        }
    } else {
        medova_global_header_option();
    }