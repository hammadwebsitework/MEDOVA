<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit();
    }

    if( defined( 'CMB2_LOADED' )  ){
        if( !empty( medova_meta('page_breadcrumb_area') ) ) {
            $medova_page_breadcrumb_area  = medova_meta('page_breadcrumb_area');
        } else {
            $medova_page_breadcrumb_area = '1';
        }
    }else{
        $medova_page_breadcrumb_area = '1';
    }
    
    $allowhtml = array(
        'p'         => array(
            'class'     => array()
        ),
        'span'      => array(
            'class'     => array(),
        ),
        'a'         => array(
            'href'      => array(),
            'title'     => array()
        ),
        'br'        => array(),
        'em'        => array(),
        'strong'    => array(),
        'b'         => array(),
        'sub'       => array(),
        'sup'       => array(),
    );
    
    if(  is_page() || is_page_template( 'template-builder.php' )  ) {
        if( $medova_page_breadcrumb_area == '1' ) {
            echo '<!-- Page title 2 -->';
            
            if( class_exists( 'ReduxFramework' ) ){
                $ex_class = '';
            }else{
                $ex_class = ' th-breadcumb';   
            }
            echo '<div class="breadcumb-wrapper '. esc_attr($ex_class).'">';
                echo '<div class="container">';
                    echo '<div class="row justify-content-center">';
                        echo '<div class="col-xl-9">';
                            echo '<div class="breadcumb-content">';
                                if( defined('CMB2_LOADED') || class_exists('ReduxFramework') ) {
                                    if( !empty( medova_meta('page_breadcrumb_settings') ) ) {
                                        if( medova_meta('page_breadcrumb_settings') == 'page' ) {
                                            $medova_page_title_switcher = medova_meta('page_title');
                                        } else {
                                            $medova_page_title_switcher = medova_opt('medova_page_title_switcher');
                                        }
                                    } else {
                                        $medova_page_title_switcher = '1';
                                    }
                                } else {
                                    $medova_page_title_switcher = '1';
                                }

                                if( $medova_page_title_switcher ){
                                    if( class_exists( 'ReduxFramework' ) ){
                                        $medova_page_title_tag    = medova_opt('medova_page_title_tag');
                                    }else{
                                        $medova_page_title_tag    = 'h1';
                                    }

                                    if( defined( 'CMB2_LOADED' )  ){
                                        if( !empty( medova_meta('page_title_settings') ) ) {
                                            $medova_custom_title = medova_meta('page_title_settings');
                                        } else {
                                            $medova_custom_title = 'default';
                                        }
                                    }else{
                                        $medova_custom_title = 'default';
                                    }

                                    if( $medova_custom_title == 'default' ) {
                                        echo medova_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $medova_page_title_tag ),
                                                "text"  => esc_html( get_the_title( ) ),
                                                'class' => 'breadcumb-title'
                                            )
                                        );
                                    } else {
                                        echo medova_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $medova_page_title_tag ),
                                                "text"  => esc_html( medova_meta('custom_page_title') ),
                                                'class' => 'breadcumb-title'
                                            )
                                        );
                                    }

                                }
                                if( defined('CMB2_LOADED') || class_exists('ReduxFramework') ) {

                                    if( medova_meta('page_breadcrumb_settings') == 'page' ) {
                                        $medova_breadcrumb_switcher = medova_meta('page_breadcrumb_trigger');
                                    } else {
                                        $medova_breadcrumb_switcher = medova_opt('medova_enable_breadcrumb');
                                    }

                                } else {
                                    $medova_breadcrumb_switcher = '1';
                                }

                                if( $medova_breadcrumb_switcher == '1' && (  is_page() || is_page_template( 'template-builder.php' ) )) {
                                        medova_breadcrumbs(
                                            array(
                                                'breadcrumbs_classes' => '',
                                            )
                                        );
                                }
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';

            echo '</div>';
            echo '<!-- End of Page title -->';
            
        }
    } else {
        echo '<!-- Page title 3 -->';
         if( class_exists( 'ReduxFramework' ) ){
            $ex_class = '';
            if (class_exists( 'woocommerce' ) && is_shop()){
            $breadcumb_bg_class = 'custom-woo-class';
            }elseif(is_404()){
                $breadcumb_bg_class = 'custom-error-class';
            }elseif(is_search()){
                $breadcumb_bg_class = 'custom-search-class';
            }elseif(is_archive()){
                $breadcumb_bg_class = 'custom-archive-class';
            }else{
                $breadcumb_bg_class = '';
            }
        }else{
            $breadcumb_bg_class = ''; 
            $ex_class = ' th-breadcumb';     
        }
        echo '<div class="breadcumb-wrapper '. esc_attr($breadcumb_bg_class . $ex_class).'">'; 
            echo '<div class="container z-index-common">';
                    echo '<div class="breadcumb-content">';
                        if( class_exists( 'ReduxFramework' )  ){
                            $medova_page_title_switcher  = medova_opt('medova_page_title_switcher');
                        }else{
                            $medova_page_title_switcher = '1';
                        }

                        if( $medova_page_title_switcher ){
                            if( class_exists( 'ReduxFramework' ) ){
                                $medova_page_title_tag    = medova_opt('medova_page_title_tag');
                            }else{
                                $medova_page_title_tag    = 'h1';
                            }
                            if( class_exists('woocommerce') && is_shop() ) {
                                echo medova_heading_tag(
                                    array(
                                        "tag"   => esc_attr( $medova_page_title_tag ),
                                        "text"  => wp_kses( woocommerce_page_title( false ), $allowhtml ),
                                        'class' => 'breadcumb-title'
                                    )
                                );
                            }elseif ( is_archive() ){
                                echo medova_heading_tag(
                                    array(
                                        "tag"   => esc_attr( $medova_page_title_tag ),
                                        "text"  => wp_kses( get_the_archive_title(), $allowhtml ),
                                        'class' => 'breadcumb-title'
                                    )
                                );
                            }elseif ( is_home() ){
                                $medova_blog_page_title_setting = medova_opt('medova_blog_page_title_setting');
                                $medova_blog_page_title_switcher = medova_opt('medova_blog_page_title_switcher');
                                $medova_blog_page_custom_title = medova_opt('medova_blog_page_custom_title');
                                if( class_exists('ReduxFramework') ){
                                    if( $medova_blog_page_title_switcher ){
                                        echo medova_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $medova_page_title_tag ),
                                                "text"  => !empty( $medova_blog_page_custom_title ) && $medova_blog_page_title_setting == 'custom' ? esc_html( $medova_blog_page_custom_title) : esc_html__( 'Latest News', 'medova' ),
                                                'class' => 'breadcumb-title'
                                            )
                                        );
                                    }
                                }else{
                                    echo medova_heading_tag(
                                        array(
                                            "tag"   => "h1",
                                            "text"  => esc_html__( 'Latest News', 'medova' ),
                                            'class' => 'breadcumb-title',
                                        )
                                    );
                                }
                            }elseif( is_search() ){
                                echo medova_heading_tag(
                                    array(
                                        "tag"   => esc_attr( $medova_page_title_tag ),
                                        "text"  => esc_html__( 'Search Result', 'medova' ),
                                        'class' => 'breadcumb-title'
                                    )
                                );
                            }elseif( is_404() ){
                                echo medova_heading_tag(
                                    array(
                                        "tag"   => esc_attr( $medova_page_title_tag ),
                                        "text"  => esc_html__( 'Error Page', 'medova' ),
                                        'class' => 'breadcumb-title'
                                    )
                                );
                            }elseif( is_singular( 'product' ) ){
                                $posttitle_position  = medova_opt('medova_product_details_title_position');
                                $postTitlePos = false;
                                if( class_exists( 'ReduxFramework' ) ){
                                    if( $posttitle_position && $posttitle_position != 'header' ){
                                        $postTitlePos = true;
                                    }
                                }else{
                                    $postTitlePos = false;
                                }

                                if( $postTitlePos != true ){
                                    echo medova_heading_tag(
                                        array(
                                            "tag"   => esc_attr( $medova_page_title_tag ),
                                            "text"  => wp_kses( get_the_title( ), $allowhtml ),
                                            'class' => 'breadcumb-title'
                                        )
                                    );
                                } else {
                                    if( class_exists( 'ReduxFramework' ) ){
                                        $medova_post_details_custom_title  = medova_opt('medova_product_details_custom_title');
                                    }else{
                                        $medova_post_details_custom_title = __( 'Shop Details','medova' );
                                    }

                                    if( !empty( $medova_post_details_custom_title ) ) {
                                        echo medova_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $medova_page_title_tag ),
                                                "text"  => wp_kses( $medova_post_details_custom_title, $allowhtml ),
                                                'class' => 'breadcumb-title'
                                            )
                                        );
                                    }
                                }
                            }else{
                                $posttitle_position  = medova_opt('medova_post_details_title_position');
                                $postTitlePos = false;
                                if( is_single() ){
                                    if( class_exists( 'ReduxFramework' ) ){
                                        if( $posttitle_position && $posttitle_position != 'header' ){
                                            $postTitlePos = true;
                                        }
                                    }else{
                                        $postTitlePos = false;
                                    }
                                }
                                if( is_singular( 'product' ) ){
                                    $posttitle_position  = medova_opt('medova_product_details_title_position');
                                    $postTitlePos = false;
                                    if( class_exists( 'ReduxFramework' ) ){
                                        if( $posttitle_position && $posttitle_position != 'header' ){
                                            $postTitlePos = true;
                                        }
                                    }else{
                                        $postTitlePos = false;
                                    }
                                }

                                if( $postTitlePos != true ){
                                    echo medova_heading_tag(
                                        array(
                                            "tag"   => esc_attr( $medova_page_title_tag ),
                                            "text"  => wp_kses( get_the_title( ), $allowhtml ),
                                            'class' => 'breadcumb-title'
                                        )
                                    );
                                } else {
                                    if( class_exists( 'ReduxFramework' ) ){
                                        $medova_post_details_custom_title  = medova_opt('medova_post_details_custom_title');
                                    }else{
                                        $medova_post_details_custom_title = __( 'Blog Details','medova' );
                                    }

                                    if( !empty( $medova_post_details_custom_title ) ) {
                                        echo medova_heading_tag(
                                            array(
                                                "tag"   => esc_attr( $medova_page_title_tag ),
                                                "text"  => wp_kses( $medova_post_details_custom_title, $allowhtml ),
                                                'class' => 'breadcumb-title'
                                            )
                                        );
                                    }
                                }
                            }
                        }
                        if( class_exists('ReduxFramework') ) {
                            $medova_breadcrumb_switcher = medova_opt( 'medova_enable_breadcrumb' );
                        } else {
                            $medova_breadcrumb_switcher = '1';
                        }
                        if( $medova_breadcrumb_switcher == '1' ) {
                            if(medova_breadcrumbs()){
                            echo '<div>';
                                medova_breadcrumbs(
                                    array(
                                        'breadcrumbs_classes' => 'nav',
                                    )
                                );
                            echo '</div>';
                            }
                        }
                    echo '</div>';
            echo '</div>';

        echo '</div>';
        echo '<!-- End of Page title -->';
    }