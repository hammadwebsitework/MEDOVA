jQuery(document).ready(function($) {
    $('body').on('click', '.remove_from_cart_button_ajax', function(e) {
        e.preventDefault();

        var $this = $(this);
        var product_id    = $this.data('product_id');
        var cart_item_key = $this.data('cart_item_key');

        $.ajax({
            url: ajax_cart_params.ajax_url,
            type: 'POST',
            data: {
                action: 'medova_remove_cart_item',
                product_id: product_id,
                cart_item_key: cart_item_key,
                nonce: ajax_cart_params.nonce
            },
            success: function(response) {
                if(response.success) {
                    // Replace mini cart content with updated fragments
                    $('div.widget_shopping_cart_content').replaceWith(response.data.fragments['div.widget_shopping_cart_content']);
                    // Refresh other cart fragments like count
                    $(document.body).trigger('wc_fragment_refresh');
                } else {
                    console.log('Remove failed:', response.data.error);
                }
            },
            error: function() {
                console.log('AJAX request failed');
            }
        });
    });
});
