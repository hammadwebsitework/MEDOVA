<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
    
    /**
    *
    * Hook for Footer Content
    *
    * Hook medova_footer_content
    *
    * @Hooked medova_footer_content_cb 10
    *
    */
    do_action( 'medova_footer_content' );


    /**
    *
    * Hook for Back to Top Button
    *
    * Hook medova_back_to_top
    *
    * @Hooked medova_back_to_top_cb 10
    *
    */
    do_action( 'medova_back_to_top' );

    /**
    *
    * medova grid lines
    *
    * Hook medova_grid_lines
    *
    * @Hooked medova_grid_lines_cb 10
    *
    */
    do_action( 'medova_grid_lines' );

    wp_footer();
    ?>
</body>
</html>