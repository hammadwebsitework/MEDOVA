<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// Block direct access
if ( !defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'medova_setup' ) ){
    function medova_setup() {

    	$selected_options   =   get_option('et_selected_medova_demo_plugin');

        // content width
        $GLOBALS['content_width'] = apply_filters( 'medova_content_width', 751 );

        // language file
		load_theme_textdomain( 'medova', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// title tag
		add_theme_support( 'title-tag' );

		// post thumbnails
		add_theme_support( 'post-thumbnails' );

        add_image_size( 'medova-shop-single',780,658,true );
        add_image_size( 'medova-shop-small-image',506,407,true ); 
        add_image_size( 'medova-shop-small-tab-image',202,170,true ); 
        add_image_size( 'medova_85X85',85,85,true );

        register_nav_menus( array(
            'primary-menu'      => esc_html__( 'Primary Menu', 'medova' ),
        ) );

		//support html5
		add_theme_support(
			'html5',
			array(
				'search-form',
				'comment-form',
				'comment-list',
				'gallery',
				'caption',
				'script',
				'style'
			)
		);


        // support post format
        add_theme_support( 'post-formats', array( 'audio', 'video', 'gallery', 'quote') );

		// Custom logo
		add_theme_support( 'custom-logo' );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Block Styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for full and wide align images.
		add_theme_support( 'align-wide' );

		// Add support for editor styles.
		add_theme_support( 'editor-styles' );

		// Enqueue editor styles.
		add_editor_style( 'assets/css/style-editor.css' );

		// Add support for responsive embedded content.
		add_theme_support( 'responsive-embeds' );
		add_theme_support('custom-header');
		add_theme_support('custom-background');

		
        // support woocommerce
        add_theme_support( 'woocommerce' );
        add_theme_support( 'wc-product-gallery-zoom' );
        add_theme_support( 'wc-product-gallery-slider' );

        // medova options
		require_once MEDOVA_DIR_PATH_FRAM . 'medova-options/medova-options.php';
	    

	}
}
add_action( 'after_setup_theme', 'medova_setup' );