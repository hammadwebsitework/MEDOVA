<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( ! defined( 'ABSPATH' ) ){
        exit();
    }


    // preloader hook function
    if( ! function_exists( 'medova_preloader_wrap_cb' ) ) {
        function medova_preloader_wrap_cb() {
            $preloader_display              =  medova_opt('medova_display_preloader');
            $medova_preloader_logo              =  medova_opt('medova_preloader_logo', 'url' );
            $medova_site_logo              =  medova_opt('medova_site_logo', 'url' );
            $preloader_text_cancel              =  medova_opt('medova_preloader_cancel_text');



            if( class_exists('ReduxFramework') ){
                if( $preloader_display ){
                    echo '<div class="preloader ">';
                        echo '<button class="th-btn preloaderCls">'.esc_html( $preloader_text_cancel ).' </button>';
                        echo '<div class="preloader-inner">';
                            echo '<img src="'.esc_url( $medova_site_logo ).'" alt="img">';
                            echo '<div class="heart-rate">';
                                echo '<img src="'.esc_url( $medova_preloader_logo ).'" alt="img">';

                                echo '<div class="fade-in"></div>';

                                echo '<div class="fade-out"></div>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                }
            }else{
                echo '<div class="preloader">';
                    echo '<button class="th-btn btn-mask th-btn-icon style2 shadow-1 preloaderCls">'.esc_html__( 'Cancel Preloader', 'medova' ).'</button>';
                    echo '<div class="preloader-inner">';
                        echo '<div class="loader"></div>';
                    echo '</div>';
                echo '</div>';
            }

        }
    }

    // Header Hook function
    if( !function_exists('medova_header_cb') ) { 
        function medova_header_cb( ) {
            get_template_part('templates/header');
            get_template_part('templates/header-menu-bottom');
        }
    }

    // back top top hook function
    if( ! function_exists( 'medova_back_to_top_cb' ) ) {
        function medova_back_to_top_cb( ) {
            $backtotop_trigger = medova_opt('medova_display_bcktotop');
            if( class_exists( 'ReduxFramework' ) ) {
                if( $backtotop_trigger ) {
            	?>
                    <div class="scroll-top">
                        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
                            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;">
                            </path>
                        </svg>
                    </div>
                <?php 
                }
            }

        }
    }

    // Blog Start Wrapper Function
    if( !function_exists('medova_blog_start_wrap_cb') ) {
        function medova_blog_start_wrap_cb() { ?>
            <section class="th-blog-wrapper space-top space-extra-bottom">
                <div class="container">
                    <div class="row">
        <?php }
    }

    // Blog End Wrapper Function
    if( !function_exists('medova_blog_end_wrap_cb') ) {
        function medova_blog_end_wrap_cb() {?>
                    </div>
                </div>
            </section>
        <?php }
    }

    // Blog Column Start Wrapper Function
    if( !function_exists('medova_blog_col_start_wrap_cb') ) {
        function medova_blog_col_start_wrap_cb() {
           
                //Redux option work
                if( class_exists('ReduxFramework') ) {
                    $medova_blog_sidebar = medova_opt('medova_blog_sidebar');
                }else{
                    $medova_blog_sidebar = '1';
                }

                if( class_exists('ReduxFramework') ) {
                    if( $medova_blog_sidebar == '2' && is_active_sidebar('medova-blog-sidebar') ) {
                        echo '<div class="col-xxl-8 col-lg-7  order-lg-last">';
                    } elseif( $medova_blog_sidebar == '3' && is_active_sidebar('medova-blog-sidebar') ) {
                        echo '<div class="col-xxl-8 col-lg-7">';
                    } else {
                        echo '<div class="col-lg-12">';
                    }

                } else {
                    if( is_active_sidebar('medova-blog-sidebar') ) {
                        echo '<div class="col-xxl-8 col-lg-7">';
                    } else {
                        echo '<div class="col-lg-12">';
                    }
                }
                

        }
    }
    // Blog Column End Wrapper Function
    if( !function_exists('medova_blog_col_end_wrap_cb') ) {
        function medova_blog_col_end_wrap_cb() {
            echo '</div>';
        }
    }

    // Blog Sidebar
    if( !function_exists('medova_blog_sidebar_cb') ) {
        function medova_blog_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_blog_sidebar = medova_opt('medova_blog_sidebar');
            } else {
                $medova_blog_sidebar = 2;
                
            }
            if( $medova_blog_sidebar != 1 && is_active_sidebar('medova-blog-sidebar') ) {
                // Sidebar
                get_sidebar();
            }
        }
    }


    if( !function_exists('medova_blog_details_sidebar_cb') ) {
        function medova_blog_details_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_blog_single_sidebar = medova_opt('medova_blog_single_sidebar');
            } else {
                $medova_blog_single_sidebar = 4;
            }
            if( $medova_blog_single_sidebar != 1 ) {
                // Sidebar
                get_sidebar();
            }

        }
    }

    // Blog Pagination Function
    if( !function_exists('medova_blog_pagination_cb') ) {
        function medova_blog_pagination_cb( ) {
            get_template_part('templates/pagination');
        }
    }

    // Blog Content Function
    if( !function_exists('medova_blog_content_cb') ) {
        function medova_blog_content_cb( ) {
            // Demo style show by get url varibale
            if ( isset( $_GET['column'] ) ) {
                $column_value = sanitize_text_field( $_GET['column'] );
            }
            if( isset( $_GET['column'] ) && ($column_value === '2' || $column_value === '3' ) ){
                if ( !empty($column_value) ) {
                    $medova_blog_grid = $column_value;
                }else{
                    $medova_blog_grid = 1;
                }
            }else{
                //Redux option work
                if( class_exists('ReduxFramework') ) {
                    $medova_blog_grid = medova_opt('medova_blog_grid');
                }else{
                    $medova_blog_grid = '1';
                }
            } //End - Demo style show by get url varibale 


            if( $medova_blog_grid == '1' ) {
                $medova_blog_grid_class = 'col-lg-12';
            } elseif( $medova_blog_grid == '2' ) {
                $medova_blog_grid_class = 'col-sm-6';
            } else {
                $medova_blog_grid_class = 'col-lg-4 col-sm-6';
            }

            echo '<div class="row">';
                if( have_posts() ) {
                    while( have_posts() ) {
                        the_post();
                        echo '<div class="'.esc_attr($medova_blog_grid_class).'">';
                            get_template_part('templates/content',get_post_format());
                        echo '</div>';
                    }
                    wp_reset_postdata();
                } else{
                    get_template_part('templates/content','none');
                }
            echo '</div>';
        }
    }

    // footer content Function
    if( !function_exists('medova_footer_content_cb') ) {
        function medova_footer_content_cb( ) {

            if( class_exists('ReduxFramework') && did_action( 'elementor/loaded' )  ){
                if( is_page() || is_page_template('template-builder.php') ) {
                    $post_id = get_the_ID();

                    // Get the page settings manager
                    $page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

                    // Get the settings model for current post
                    $page_settings_model = $page_settings_manager->get_model( $post_id );

                    // Retrieve the Footer Style
                    $footer_settings = $page_settings_model->get_settings( 'medova_footer_style' );

                    // Footer Local
                    $footer_local = $page_settings_model->get_settings( 'medova_footer_builder_option' );

                    // Footer Enable Disable
                    $footer_enable_disable = $page_settings_model->get_settings( 'medova_footer_choice' );

                    if( $footer_enable_disable == 'yes' ){
                        if( $footer_settings == 'footer_builder' ) {
                            // local options
                            $medova_local_footer = get_post( $footer_local );
                            echo '<footer>';
                            echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $medova_local_footer->ID );
                            echo '</footer>';
                        } else {
                            // global options
                            $medova_footer_builder_trigger = medova_opt('medova_footer_builder_trigger');
                            if( $medova_footer_builder_trigger == 'footer_builder' ) {
                                echo '<footer>';
                                $medova_global_footer_select = get_post( medova_opt( 'medova_footer_builder_select' ) );
                                $footer_post = get_post( $medova_global_footer_select );
                                echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $footer_post->ID );
                                echo '</footer>';
                            } else {
                                // wordpress widgets
                                medova_footer_global_option();
                            }
                        }
                    }
                } else {
                    // global options
                    $medova_footer_builder_trigger = medova_opt('medova_footer_builder_trigger');
                    if( $medova_footer_builder_trigger == 'footer_builder' ) {
                        echo '<footer>';
                        $medova_global_footer_select = get_post( medova_opt( 'medova_footer_builder_select' ) );
                        $footer_post = get_post( $medova_global_footer_select );
                        echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $footer_post->ID );
                        echo '</footer>';
                    } else {
                        // wordpress widgets
                        medova_footer_global_option();
                    }
                }
            } else { ?>
                <div class="footer-layout1 footer-sticky">
                    <div class="copyright-wrap bg-theme">
                        <div class="container">
                            <p class="copyright-text text-center text-white"><?php echo sprintf( 'Copyright <i class="fal fa-copyright"></i> %s <a class="text-white" href="%s"> %s </a> All Rights Reserved.', date('Y'), esc_url('#'), esc_html__( 'Medova.','medova') ); ?></p> 
                        </div>
                    </div>
                </div>
            <?php }

        }
    }

    // blog details wrapper start hook function
    if( !function_exists('medova_blog_details_wrapper_start_cb') ) {
        function medova_blog_details_wrapper_start_cb( ) {
            echo '<section class="th-blog-wrapper blog-details space-top space-extra-bottom">';
                echo '<div class="container">';
                    if( is_active_sidebar( 'medova-blog-sidebar' ) ){
                        $medova_gutter_class = 'gx-60';
                    }else{
                        $medova_gutter_class = '';
                    }
                    echo '<div class="row">';
        }
    }

    // blog details column wrapper start hook function
    if( !function_exists('medova_blog_details_col_start_cb') ) {
        function medova_blog_details_col_start_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_blog_single_sidebar = medova_opt('medova_blog_single_sidebar');
                if( $medova_blog_single_sidebar == '2' && is_active_sidebar('medova-blog-sidebar') ) {
                    echo '<div class="col-xxl-8 col-lg-7 order-lg-last">';
                } elseif( $medova_blog_single_sidebar == '3' && is_active_sidebar('medova-blog-sidebar') ) {
                    echo '<div class="col-xxl-8 col-lg-7">';
                } else {
                    echo '<div class="col-lg-12">';
                }

            } else {
                if( is_active_sidebar('medova-blog-sidebar') ) {
                    echo '<div class="col-xxl-8 col-lg-7">';
                } else {
                    echo '<div class="col-lg-12">';
                }
            }
        }
    }

    // blog details post meta hook function
    if( !function_exists('medova_blog_post_meta_cb') ) {
        function medova_blog_post_meta_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_display_post_author      =  medova_opt('medova_display_post_author');
                $medova_display_post_date      =  medova_opt('medova_display_post_date');
                $medova_display_post_cate   =  medova_opt('medova_display_post_cate');
                $medova_display_post_comments      =  medova_opt('medova_display_post_comments');
            } else {
                $medova_display_post_author      = '1';
                $medova_display_post_date      = '1';
                $medova_display_post_cate   = '1';
                $medova_display_post_comments      = '0'; 
            }

                echo '<div class="blog-meta">';
                    if( $medova_display_post_author ){
                        echo '<a href="'.esc_url( get_author_posts_url( get_the_author_meta('ID') ) ).'"><i class="fa-solid fa-user"></i>'.esc_html( ucwords( get_the_author() ) ).'</a>';
                    }
                    if( $medova_display_post_date ){
                        echo ' <a href="'.esc_url( medova_blog_date_permalink() ).'"><i class="fa-solid fa-calendar-days"></i>'.esc_html( get_the_date() ).'</a>';
                    }
                    if( $medova_display_post_cate ){
                        $categories = get_the_category(); 
                        if(!empty($categories)){
                        echo '<a href="'.esc_url( get_category_link( $categories[0]->term_id ) ).'"><i class="far fa-house-building"></i>'.esc_html( $categories[0]->name ).'</a>';
                        }
                    }
                    if( $medova_display_post_comments ){
                        ?>
                        <a href="#"><i class="fa-solid fa-comments"></i>
                            <?php 
                                if(get_comments_number() == 1){
                                    echo esc_html__('Comment (', 'medova'); 
                                }else{
                                    echo esc_html__('Comments (', 'medova'); 
                                }
                                echo get_comments_number(); ?>)</a>
                        <?php
                    }
                echo '</div>';
        }
    }

    // blog details share options hook function
    if( !function_exists('medova_blog_details_share_options_cb') ) {
        function medova_blog_details_share_options_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_post_details_share_options = medova_opt('medova_post_details_share_options');
            } else {
                $medova_post_details_share_options = false;
            }
            if( function_exists( 'medova_social_sharing_buttons' ) && $medova_post_details_share_options ) { ?>
                <div class="col-sm-auto text-xl-end">
                    <span class="share-links-title"><?php echo esc_html__('Share:', 'medova') ?></span>
                    <ul class="social-links">
                        <?php echo medova_social_sharing_buttons(); ?>
                    </ul>
                </div>
            <?php }
        }
    }
    
    // blog details author bio hook function
    if( !function_exists('medova_blog_details_author_bio_cb') ) {
        function medova_blog_details_author_bio_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $postauthorbox =  medova_opt( 'medova_post_details_author_box' );
            } else {
                $postauthorbox = '0';
            }
            if(  $postauthorbox == '1' ) {

                echo '<div class="author-widget-wrap">';
                        echo '<div class="avater">';
                            echo '<img src="'.esc_url( get_avatar_url( get_the_author_meta('ID') ) ).'" alt="img">';
                        echo '</div>';
                        echo '<div class="avater-content">';
                            echo ' <div class="author-info">';
                                echo '<h3 class="name"><a class="text-inherit" href="#">'.esc_html( ucwords( get_the_author() )).'</a></h3>';
                                echo '<span class="text">'.get_user_meta( get_the_author_meta('ID'), '_medova_author_desig',true ).'</span>';
                            echo '</div>';
                            echo '<p class="author-bio">'.get_the_author_meta( 'user_description', get_the_author_meta('ID') ).'</p>';
                            echo '<div class="social-links">';
                                    $medova_social_icons = get_user_meta( get_the_author_meta('ID'), '_medova_social_profile_group',true );
                                    if(!empty($medova_social_icons)){
                                        foreach( $medova_social_icons as $singleicon ) {
                                            if( ! empty( $singleicon['_medova_social_profile_icon'] ) ) {
                                                echo '<a href="'.esc_url( $singleicon['_medova_lawyer_social_profile_link'] ).'"><i class="'.esc_attr( $singleicon['_medova_social_profile_icon'] ).'"></i></a>';
                                            }
                                        }
                                    }
                            echo '</div>';
                        echo '</div>';
             echo '</div>';

               
            }

        }
    }

     // Blog Details Post Navigation hook function
     if( !function_exists( 'medova_blog_details_post_navigation_cb' ) ) {
        function medova_blog_details_post_navigation_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_post_navigation = medova_opt('medova_post_details_post_navigation');
            } else {
                $medova_post_navigation = 0;
            }

            $prevpost = get_previous_post();
            $nextpost = get_next_post();

            $allowhtml = array(
                'p'         => array(
                    'class'     => array()
                ),
                'span'      => array(),
                'a'         => array(
                    'href'      => array(),
                    'title'     => array()
                ),
                'br'        => array(),
                'em'        => array(),
                'strong'    => array(),
                'b'         => array(),
            );

            if( ($medova_post_navigation == '1') && (!empty($prevpost) || !empty($nextpost)) ) {
                echo '<div class="blog-navigation">';
                    echo '<div>';
                        if( ! empty( $prevpost ) ) {
                            echo '<a href="'.esc_url( get_permalink( $prevpost->ID ) ).'" class="nav-btn prev">';
                            if( class_exists('ReduxFramework') ) {
                                if (has_post_thumbnail( $prevpost->ID )) {
                                    echo get_the_post_thumbnail( $prevpost->ID, 'medova_85X85' );
                                };
                            }
                                echo '<span class="nav-text">'.esc_html__( ' Previous Post', 'medova' ).'</span>';
                            echo '</a>';
                        }
                    echo '</div>';

                    echo '<a href="'.get_permalink( get_option( 'page_for_posts' ) ).'" class="blog-btn"><i class="fa-solid fa-grid"></i></a>';

                    echo '<div>';
                        if( ! empty( $nextpost ) ) {
                            echo '<a href="'.esc_url( get_permalink( $nextpost->ID ) ).'" class="nav-btn next">';
                                if( class_exists('ReduxFramework') ) {
                                    if (has_post_thumbnail($nextpost->ID)) {
                                        echo get_the_post_thumbnail( $nextpost->ID, 'medova_85X85' );
                                    };
                                }
                                echo '<span class="nav-text">'.esc_html__( ' Next Post', 'medova' ).'</span>';
                            echo '</a>';
                        }
                    echo '</div>';
                echo '</div>';
            }

        }
    }

    // Blog Details Comments hook function
    if( !function_exists('medova_blog_details_comments_cb') ) {
        function medova_blog_details_comments_cb( ) {
            if ( ! comments_open() ) {
                echo '<div class="blog-comment-area">';
                    echo medova_heading_tag( array(
                        "tag"   => "h3",
                        "text"  => esc_html__( 'Comments are closed', 'medova' ),
                        "class" => "inner-title"
                    ) );
                echo '</div>';
            }

            // comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }
        }
    }

    // Blog Details Column end hook function
    if( !function_exists('medova_blog_details_col_end_cb') ) {
        function medova_blog_details_col_end_cb( ) {
            echo '</div>';
        }
    }

    // Blog Details Wrapper end hook function
    if( !function_exists('medova_blog_details_wrapper_end_cb') ) {
        function medova_blog_details_wrapper_end_cb( ) {
                    echo '</div>';
                echo '</div>';
            echo '</section>';
        }
    }

    // page start wrapper hook function
    if( !function_exists('medova_page_start_wrap_cb') ) {
        function medova_page_start_wrap_cb( ) {
            
            if( is_page( 'cart' ) ){
                $section_class = "th-cart-wrapper space-top space-extra-bottom";
            }elseif( is_page( 'checkout' ) ){
                $section_class = "th-checkout-wrapper space-top space-extra-bottom";
            }elseif( is_page('wishlist') ){
                $section_class = "wishlist-area space-top space-extra-bottom";
            }else{
                $section_class = "space-top space-extra-bottom";  
            }
            echo '<section class="'.esc_attr( $section_class ).'">';
                echo '<div class="container">';
                    echo '<div class="row">';
        }
    }

    // page wrapper end hook function
    if( !function_exists('medova_page_end_wrap_cb') ) {
        function medova_page_end_wrap_cb( ) {
                    echo '</div>';
                echo '</div>';
            echo '</section>';
        }
    }

    // page column wrapper start hook function
    if( !function_exists('medova_page_col_start_wrap_cb') ) {
        function medova_page_col_start_wrap_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_page_sidebar = medova_opt('medova_page_sidebar');
            }else {
                $medova_page_sidebar = '1';
            }
            
            if( $medova_page_sidebar == '2' && is_active_sidebar('medova-page-sidebar') ) {
                echo '<div class="col-lg-8 order-last">';
            } elseif( $medova_page_sidebar == '3' && is_active_sidebar('medova-page-sidebar') ) {
                echo '<div class="col-lg-8">';
            } else {
                echo '<div class="col-lg-12">';
            }

        }
    }

    // page column wrapper end hook function
    if( !function_exists('medova_page_col_end_wrap_cb') ) {
        function medova_page_col_end_wrap_cb( ) {
            echo '</div>';
        }
    }

    // page sidebar hook function
    if( !function_exists('medova_page_sidebar_cb') ) {
        function medova_page_sidebar_cb( ) {
            if( class_exists('ReduxFramework') ) {
                $medova_page_sidebar = medova_opt('medova_page_sidebar');
            }else {
                $medova_page_sidebar = '1';
            }

            if( class_exists('ReduxFramework') ) {
                $medova_page_layoutopt = medova_opt('medova_page_layoutopt');
            }else {
                $medova_page_layoutopt = '3';
            }

            if( $medova_page_layoutopt == '1' && $medova_page_sidebar != 1 ) {
                get_sidebar('page');
            } elseif( $medova_page_layoutopt == '2' && $medova_page_sidebar != 1 ) {
                get_sidebar();
            }
        }
    }

    // page content hook function
    if( !function_exists('medova_page_content_cb') ) {
        function medova_page_content_cb( ) {
            if(  class_exists('woocommerce') && ( is_woocommerce() || is_cart() || is_checkout() || is_page('wishlist') || is_account_page() )  ) {
                echo '<div class="woocommerce--content">';
            } else {
                echo '<div class="page--content clearfix">';
            }

                the_content();

                // Link Pages
                medova_link_pages();

            echo '</div>';
            // comment template.
            if ( comments_open() || get_comments_number() ) {
                comments_template();
            }

        }
    }

    if( !function_exists('medova_blog_post_thumb_cb') ) {
        function medova_blog_post_thumb_cb( ) {
            if( get_post_format() ) {
                $format = get_post_format();
            }else{
                $format = 'standard';
            }

            $medova_post_slider_thumbnail = medova_meta( 'post_format_slider' );

            if( !empty( $medova_post_slider_thumbnail ) ){
                echo '<div class="blog-img th-slider" data-slider-options=\'{"effect":"fade"}\'>';
                    echo '<div class="swiper-wrapper">';
                        foreach( $medova_post_slider_thumbnail as $single_image ){
                            echo '<div class="swiper-slide">';
                                echo medova_img_tag( array(
                                    'url'   => esc_url( $single_image )
                                ) );
                            echo '</div>';
                        }
                    echo '</div>';
                    echo '<button class="slider-arrow slider-prev"><i class="far fa-arrow-left"></i></button>';
                    echo '<button class="slider-arrow slider-next"><i class="far fa-arrow-right"></i></button>';
                echo '</div>';

            }elseif( has_post_thumbnail() && $format == 'standard' ) {
                echo '<!-- Post Thumbnail -->';
                echo '<div class="blog-img global-img">';
                    if( ! is_single() ){
                        echo '<a href="'.esc_url( get_permalink() ).'" class="post-thumbnail">';
                    }

                    the_post_thumbnail();

                    if( ! is_single() ){
                        echo '</a>';
                    }
                echo '</div>';
                echo '<!-- End Post Thumbnail -->';
            }elseif( $format == 'video' ){
                if( has_post_thumbnail() && ! empty ( medova_meta( 'post_format_video' ) ) ){
                    echo '<div class="blog-img blog-video" data-overlay="title" data-opacity="4">';
                        if( ! is_single() ){
                            echo '<a href="'.esc_url( get_permalink() ).'" class="post-thumbnail">';
                        }
                            the_post_thumbnail();

                        if( ! is_single() ){
                            echo '</a>';
                        }
                        echo '<a href="'.esc_url( medova_meta( 'post_format_video' ) ).'" class="play-btn popup-video">';
                            echo '<i class="fas fa-play"></i>';
                        echo '</a>';
                    echo '</div>';
                }elseif( ! has_post_thumbnail() && ! is_single() ){
                    echo '<div class="blog-video">';
                        if( ! is_single() ){
                            echo '<a href="'.esc_url( get_permalink() ).'" class="post-thumbnail">';
                        }
                            echo medova_embedded_media( array( 'video', 'iframe' ) );
                        if( ! is_single() ){
                            echo '</a>';
                        }
                    echo '</div>';
                }
            }elseif( $format == 'audio' ){
                $medova_audio = medova_meta( 'post_format_audio' );
                if( ! empty( $medova_audio ) ){
                    echo '<div class="blog-audio">';
                        echo wp_oembed_get( $medova_audio );
                    echo '</div>';
                }elseif( ! is_single() ){
                    echo '<div class="blog-audio">';
                        echo wp_oembed_get( $medova_audio );
                    echo '</div>';
                }
            }

        }
    }

    if( !function_exists('medova_blog_post_content_cb') ) {
        function medova_blog_post_content_cb( ) {
            $allowhtml = array(
                'p'         => array(
                    'class'     => array()
                ),
                'span'      => array(),
                'a'         => array(
                    'href'      => array(),
                    'title'     => array()
                ),
                'br'        => array(),
                'em'        => array(),
                'strong'    => array(),
                'b'         => array(),
            );
            if( class_exists( 'ReduxFramework' ) ) {
                $medova_excerpt_length          = medova_opt( 'medova_blog_postExcerpt' );
                $medova_display_post_category   = medova_opt( 'medova_display_post_category' );
            } else {
                $medova_excerpt_length          = '48';
                $medova_display_post_category   = '1';
            }

            if( class_exists( 'ReduxFramework' ) ) {
                $medova_blog_admin = medova_opt( 'medova_blog_post_author' );
                $medova_blog_readmore_setting_val = medova_opt('medova_blog_readmore_setting');
                if( $medova_blog_readmore_setting_val == 'custom' ) {
                    $medova_blog_readmore_setting = medova_opt('medova_blog_custom_readmore');
                } else {
                    $medova_blog_readmore_setting = __( 'Read More', 'medova' );
                }
            } else {
                $medova_blog_readmore_setting = __( 'Read More', 'medova' );
                $medova_blog_admin = true;
            }
            echo '<!-- blog-content -->';

                do_action( 'medova_blog_post_thumb' );
                
                echo '<div class="blog-content">';

                    // Blog Post Meta
                    do_action( 'medova_blog_post_meta' );

                    echo '<!-- Post Title -->';
                    echo '<h3 class="blog-title"><a href="'.esc_url( get_permalink() ).'">'.wp_kses( get_the_title( ), $allowhtml ).'</a></h3>';
                    echo '<!-- End Post Title -->';

                    echo '<!-- Post Summary -->';
                    echo medova_paragraph_tag( array(
                        "text"  => wp_kses( wp_trim_words( get_the_excerpt(), $medova_excerpt_length, '' ), $allowhtml ),
                        "class" => 'blog-text',
                    ) );
  
                    if( !empty( $medova_blog_readmore_setting ) ){
                        echo '<a href="'.esc_url( get_permalink() ).'" class="line-btn">'.esc_html( $medova_blog_readmore_setting ).'<i class="fa-light fa-arrow-right-long ms-2"></i></a>';
                    }

                    echo '<!-- End Post Summary -->';
                echo '</div>';
            echo '<!-- End Post Content -->';
        }
    }
