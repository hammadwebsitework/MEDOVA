<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */


// Block direct access
if( ! defined( 'ABSPATH' ) ){
    exit;
}

 // theme option callback
function medova_opt( $id = null, $url = null ){
    global $medova_opt;

    if( $id && $url ){

        if( isset( $medova_opt[$id][$url] ) && $medova_opt[$id][$url] ){
            return $medova_opt[$id][$url];
        }
    }else{
        if( isset( $medova_opt[$id] )  && $medova_opt[$id] ){ 
            return $medova_opt[$id];
        }
    }
}


// theme logo
function medova_theme_logo() {
    // escaping allow html
    $allowhtml = array(
        'a'    => array(
            'href' => array()
        ),
        'span' => array(),
        'i'    => array(
            'class' => array()
        )
    );
    $siteUrl = home_url('/');
    if( has_custom_logo() ) {
        $custom_logo_id = get_theme_mod( 'custom_logo' );
        $siteLogo = '';
        $siteLogo .= '<a class="logo" href="'.esc_url( $siteUrl ).'">';
        $siteLogo .= medova_img_tag( array(
            "class" => "img-fluid",
            "url"   => esc_url( wp_get_attachment_image_url( $custom_logo_id, 'full') )
        ) );
        $siteLogo .= '</a>';

        return $siteLogo;
    } elseif( !medova_opt('medova_text_title') && medova_opt('medova_site_logo', 'url' )  ){

        $siteLogo = '<img class="img-fluid" src="'.esc_url( medova_opt('medova_site_logo', 'url' ) ).'" alt="'.esc_attr__( 'logo', 'medova' ).'" />';
        return '<a class="logo" href="'.esc_url( $siteUrl ).'">'.$siteLogo.'</a>';


    }elseif( medova_opt('medova_text_title') ){
        return '<h2 class="mb-0"><a class="logo" href="'.esc_url( $siteUrl ).'">'.wp_kses( medova_opt('medova_text_title'), $allowhtml ).'</a></h2>';
    }else{
        return '<h2 class="mb-0"><a class="logo" href="'.esc_url( $siteUrl ).'">'.esc_html( get_bloginfo('name') ).'</a></h2>';
    }
}

// custom meta id callback
function medova_meta( $id = '' ){
    $value = get_post_meta( get_the_ID(), '_medova_'.$id, true );
    return $value;
}


// Blog Date Permalink
function medova_blog_date_permalink() {
    $year  = get_the_time('Y');
    $month_link = get_the_time('m');
    $day   = get_the_time('d');
    $link = get_day_link( $year, $month_link, $day);
    return $link;
}

//audio format iframe match
function medova_iframe_match() {
    $audio_content = medova_embedded_media( array('audio', 'iframe') );
    $iframe_match = preg_match("/\iframe\b/i",$audio_content, $match);
    return $iframe_match;
}


//Post embedded media
function medova_embedded_media( $type = array() ){
    $content = do_shortcode( apply_filters( 'the_content', get_the_content() ) );
    $embed   = get_media_embedded_in_content( $content, $type );


    if( in_array( 'audio' , $type) ){
        if( count( $embed ) > 0 ){
            $output = str_replace( '?visual=true', '?visual=false', $embed[0] );
        }else{
           $output = '';
        }

    }else{
        if( count( $embed ) > 0 ){
            $output = $embed[0];
        }else{
           $output = '';
        }
    }
    return $output;
}


// WP post link pages
function medova_link_pages(){
    wp_link_pages( array(
        'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'medova' ) . '</span>',
        'after'       => '</div>',
        'link_before' => '<span>',
        'link_after'  => '</span>',
        'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'medova' ) . ' </span>%',
        'separator'   => '<span class="screen-reader-text">, </span>',
    ) );
}


// Data Background image attr
function medova_data_bg_attr( $imgUrl = '' ){
    return 'data-bg-img="'.esc_url( $imgUrl ).'"';
}

// image alt tag
function medova_image_alt( $url = '' ){
    if( $url != '' ){
        // attachment id by url
        $attachmentid = attachment_url_to_postid( esc_url( $url ) );
       // attachment alt tag
        $image_alt = get_post_meta( esc_html( $attachmentid ) , '_wp_attachment_image_alt', true );
        if( $image_alt ){
            return $image_alt ;
        }else{
            $filename = pathinfo( esc_url( $url ) );
            $alt = str_replace( '-', ' ', $filename['filename'] );
            return $alt;
        }
    }else{
       return;
    }
}


// Flat Content wysiwyg output with meta key and post id

function medova_get_textareahtml_output( $content ) {
    global $wp_embed;

    $content = $wp_embed->autoembed( $content );
    $content = $wp_embed->run_shortcode( $content );
    $content = wpautop( $content );
    $content = do_shortcode( $content );

    return $content;
}

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */

function medova_pingback_header() {
    if ( is_singular() && pings_open() ) {
        echo '<link rel="pingback" href="', esc_url( get_bloginfo( 'pingback_url' ) ), '">';
    }
}
add_action( 'wp_head', 'medova_pingback_header' );


// Excerpt More
function medova_excerpt_more( $more ) {
    return '...';
}

add_filter( 'excerpt_more', 'medova_excerpt_more' );


// medova comment template callback
function medova_comment_callback( $comment, $args, $depth ) {
        $add_below = 'comment';
    ?>
    <li <?php comment_class( array('th-comment-item') ); ?>>
        <div id="comment-<?php comment_ID() ?>" class="th-post-comment">
            <?php
                if( get_avatar( $comment, 100 )  ) :
            ?>
            <!-- Author Image -->
            <div class="comment-avater">
                <?php
                    if ( $args['avatar_size'] != 0 ) {
                        echo get_avatar( $comment, 110 );
                    }
                ?>
            </div>
            <!-- Author Image -->
            <?php endif; ?>
            <!-- Comment Content -->
            <div class="comment-content">
                <div class="">
                    <h3 class="name"><?php echo esc_html( ucwords( get_comment_author() ) ); ?></h3>
                    <span class="commented-on"><?php printf( esc_html__('%1$s - %2$s', 'medova'), get_comment_date(), get_comment_time() ); ?></span>
                </div>
                <p class="text"><?php echo get_comment_text(); ?></p>
                <div class="reply_and_edit">
                    <?php
                        $reply_text = wp_kses_post( '<i class="fas fa-reply"></i> Reply', 'medova' );

                        $edit_reply_text = wp_kses_post( '<i class="fas fa-pencil-alt"></i> Edit', 'medova' );

                        comment_reply_link(array_merge( $args, array( 'add_below' => $add_below, 'depth' => 3, 'max_depth' => 5, 'reply_text' => $reply_text ) ) );
                    ?>  
                </div>
                <?php if ( $comment->comment_approved == '0' ) : ?>
                <p class="comment-awaiting-moderation"><?php esc_html_e( 'Your comment is awaiting moderation.', 'medova' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <!-- Comment Content -->
<?php
}

//body class
add_filter( 'body_class', 'medova_body_class' );
function medova_body_class( $classes ) {
    if( class_exists('ReduxFramework') ) {
        $medova_blog_single_sidebar = medova_opt('medova_blog_single_sidebar');
        if( ($medova_blog_single_sidebar != '2' && $medova_blog_single_sidebar != '3' ) || ! is_active_sidebar('medova-blog-sidebar') ) {
            $classes[] = 'no-sidebar';
        }
        $new_class = is_page() ? medova_meta('custom_body_class') : '';

        if ( $new_class ) {
            $classes[] = $new_class;
        }
    } else {
        if( !is_active_sidebar('medova-blog-sidebar') ) {
            $classes[] = 'no-sidebar';
        }
        $classes[] .= '';
    }

    return $classes;
}

//Global Footer
function medova_footer_global_option(){
    // Medova Widget Enable Disable
    if( class_exists( 'ReduxFramework' ) ){
        $medova_footer_widget_enable = medova_opt( 'medova_footerwidget_enable' );
        $medova_footer_bottom_active = medova_opt( 'medova_disable_footer_bottom' );
        $medova_footer_social_media = medova_opt( 'medova_footer_social_media' );
    }else{
        $medova_footer_widget_enable = '';
        $medova_footer_bottom_active = '1';
        $medova_footer_social_media = '';
    }

    if( $medova_footer_widget_enable == '1' || $medova_footer_bottom_active == '1' ){
        
        
        echo '<!---footer-wrapper start-->';
        echo '<footer class="footer-wrapper footer-default bg-theme prebuilt-foo">';
            if( $medova_footer_widget_enable == '1' ){
                if( ( is_active_sidebar( 'medova-footer-1' ) || is_active_sidebar( 'medova-footer-2' ) || is_active_sidebar( 'medova-footer-3' ) || is_active_sidebar( 'medova-footer-4' ) )) {
                    echo '<div class="widget-area">';
                        echo '<div class="container">';
                                echo '<div class="row justify-content-between">';
                                    if( is_active_sidebar( 'medova-footer-1' )){
                                    dynamic_sidebar( 'medova-footer-1' ); 
                                    }
                                    if( is_active_sidebar( 'medova-footer-2' )){
                                    dynamic_sidebar( 'medova-footer-2' ); 
                                    }
                                    if( is_active_sidebar( 'medova-footer-3' )){
                                    dynamic_sidebar( 'medova-footer-3' ); 
                                    } 
                                    if( is_active_sidebar( 'medova-footer-4' )){
                                    dynamic_sidebar( 'medova-footer-4' ); 
                                    }  
                                echo '</div>';
                        echo '</div>';
                    echo '</div>';
                }
            }

            if( $medova_footer_bottom_active == '1' ){
                echo '<div class="copyright-wrap bg-light">';

                    echo '<div class="container">';
                        echo '<div class="row gy-3 align-items-center">';
                            echo '<div class="col-lg-6">';
                                echo '<p class="copyright-text">'.wp_kses_post( medova_opt( 'medova_copyright_text' ) ).'</p>';
                            echo '</div>';
                            if( $medova_footer_social_media == '1' ){
                                echo '<div class="col-lg-6">';
                                    echo '<div class="th-social justify-content-lg-end justify-content-center">';
                                        echo medova_social_icon();
                                    echo '</div>';
                                echo '</div>';
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            }

        echo '</footer>';
        echo '<!---footer-wrapper end-->';
    }
}

// Social link
function medova_social_icon(){
    $medova_social_icon = medova_opt( 'medova_social_links' );
    if( ! empty( $medova_social_icon ) && isset( $medova_social_icon ) ){
        $social_item = '';
        foreach( $medova_social_icon as $social_icon ){
            // if( !empty($social_icon['title']) || $social_icon['description'] ){
                $social_item .= '<a href="'.esc_url( $social_icon['url'] ).'"><i class="'.esc_attr( $social_icon['title'] ).'"></i>'.esc_attr( $social_icon['description'] ).'</a>';
            // }
        }
        return $social_item;
    }
}

// global header
function medova_global_header_option() {

    if( class_exists( 'ReduxFramework' ) ){ 
        echo '<header class="th-header header-default prebuilt">';

            if(medova_opt('medova_header_sticky')){
                $sticky = '';
            }else{
                $sticky = '-no';
            }

            if(medova_opt('medova_menu_icon')){ 
                $menu_icon = '';
            }else{
                $menu_icon = 'hide-icon';
            }

            echo medova_header_offcanvas();
            echo medova_mobile_menu();

            echo '<div class="sticky-wrapper'.esc_attr($sticky).'">';
                echo '<!-- Main Menu Area -->';
                echo '<div class="container">';
                    echo '<div class="menu-area">';
                        echo '<div class="row align-items-center justify-content-between">';
                            echo '<div class="col-auto">';
                                echo '<div class="header-logo">';
                                    echo medova_theme_logo();
                                echo '</div>';
                            echo '</div>';
                            echo '<div class="col-auto">';
                                echo '<nav class="main-menu d-none d-lg-inline-block '.esc_attr($menu_icon).'">';
                                    wp_nav_menu( array(
                                        "theme_location"    => 'primary-menu',
                                        "container"         => '',
                                        "menu_class"        => ''
                                    ) ); 
                                echo '</nav>';
                                echo '<div class="header-button d-flex d-lg-none">';
                                    echo '<button type="button" class="th-menu-toggle sidebar-btn">';
                                        echo '<span class="line"></span>';
                                        echo '<span class="line"></span>';
                                        echo '<span class="line"></span>';
                                    echo '</button>';
                                echo '</div>';
                            echo '</div>';
                            echo '<div class="col-auto d-none d-xxl-block">';
                                echo '<div class="header-button">';
                                    
                                    if( !empty(medova_opt( 'medova_btn_text' ) ) ){ 
                                        echo '<a href="'.esc_url(medova_opt( 'medova_btn_url' )).'" class="th-btn style-border th-btn-icon">'.wp_kses_post(medova_opt( 'medova_btn_text' )).'</a>';
                                    }
                                    if( !empty(medova_opt( 'medova_offcanvas' ) ) ){ 
                                        echo '<a href="#" class="icon-btn sideMenuToggler d-none d-lg-block"><img src="'.MEDOVA_PLUGDIRURI . 'assets/img/icons/grid.svg" alt=""></a>';
                                    }
                                echo '</div>';
                            echo '</div>';
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';

        echo '</header>';
    }else{
        echo medova_global_header();
    }
}



// medova woocommerce breadcrumb
function medova_woo_breadcrumb( $args ) {
    return array(
        'delimiter'   => '',
        'wrap_before' => '<ul class="breadcumb-menu">',
        'wrap_after'  => '</ul>',
        'before'      => '<li>',
        'after'       => '</li>',
        'home'        => _x( 'Home', 'breadcrumb', 'medova' ),
    );
}

add_filter( 'woocommerce_breadcrumb_defaults', 'medova_woo_breadcrumb' );

function medova_custom_search_form( $class ) {
    echo '<!-- Search Form -->';

    echo '<form role="search" method="get" action="'.esc_url( home_url( '/' ) ).'" class="'.esc_attr( $class ).'">';
        echo '<label class="searchIcon">';
            echo medova_img_tag( array(
                "url"   => esc_url( get_theme_file_uri( '/assets/img/search-2.svg' ) ),
                "class" => "svg"
            ) );
            echo '<input value="'.esc_html( get_search_query() ).'" name="s" required type="search" placeholder="'.esc_attr__('What are you looking for?', 'medova').'">';
        echo '</label>';
    echo '</form>';
    echo '<!-- End Search Form -->';
}



//Fire the wp_body_open action.
if ( ! function_exists( 'wp_body_open' ) ) {
    function wp_body_open() {
        do_action( 'wp_body_open' );
    }
}

//Remove Tag-Clouds inline style
add_filter( 'wp_generate_tag_cloud', 'medova_remove_tagcloud_inline_style',10,1 );
function medova_remove_tagcloud_inline_style( $input ){
   return preg_replace('/ style=("|\')(.*?)("|\')/','',$input );
}

/* This code filters the Categories archive widget to include the post count inside the link */


// Medova Default Header
if( ! function_exists( 'medova_global_header' ) ){
    function medova_global_header(){ ?>

        <!--Mobile menu & Search box-->
        <?php 
        echo medova_search_box(); 
        echo medova_mobile_menu(); 
        
        ?>

        <!--======== Header ========-->
        <header class="th-header header-default unittest-header">
            <div class="sticky-wrapper">
                <div class="sticky-active">
                    <div class="menu-area">
                        <div class="container">
                            <div class="row gx-20 align-items-center justify-content-between">

                                <div class="col-auto">
                                    <div class="header-logo">
                                        <div class="logo-bg"></div>
                                        <?php echo medova_theme_logo(); ?>
                                    </div>
                                </div>

                                <div class="col-auto">
                                    <?php
                                    if( has_nav_menu( 'primary-menu' ) ) { ?>
                                        <nav class="main-menu d-none d-lg-inline-block">
                                            <?php
                                            wp_nav_menu( array(
                                                "theme_location"    => 'primary-menu',
                                                "container"         => '',
                                                "menu_class"        => ''
                                            ) ); ?>
                                        </nav>
                                    <?php } ?>                                   
                                    </nav>
                                    <button type="button" class="th-menu-toggle d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
                                </div>
                                <div class="col-auto d-none d-xl-block">
                                    <div class="header-button">
                                        <button type="button" class="icon-btn searchBoxToggler"><i class="far fa-search"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    <?php
    }
}

//header search box
if(! function_exists('medova_search_box')){
    function medova_search_box(){
        echo '<div class="popup-search-box d-none d-lg-block">';
            echo '<button class="searchClose"><i class="fal fa-times"></i></button>';
            echo '<form role="search" method="get" action="'.esc_url( home_url( '/' ) ).'">';
                echo '<input value="'.esc_html( get_search_query() ).'" name="s" required type="search" placeholder="'.esc_attr__('What are you looking for?', 'medova').'">';
                echo '<button type="submit"><i class="fal fa-search"></i></button>';
            echo '</form>';
        echo '</div>';
    }
}

//header Offcanvas
if( ! function_exists( 'medova_header_offcanvas' ) ){
    function medova_header_offcanvas(){
        echo '<div class="sidemenu-wrapper office-info">';
            echo '<div class="sidemenu-content">';
                echo '<button class="closeButton sideMenuInfoClose"><i class="far fa-times"></i></button>';
                if(is_active_sidebar('medova-offcanvas')){
                    dynamic_sidebar( 'medova-offcanvas' );
                }else{
                    echo '<h4 class="widget_title">No Widget Added </h4>';
                    echo '<p>Please add some widget in Offcanvs Sidebar</p>';
                }
            echo '</div>';
        echo '</div>';
    }
}

//header Cart Offcanvas
if( ! function_exists( 'medova_header_cart_offcanvas' ) ){
    function medova_header_cart_offcanvas(){
        if (class_exists('WooCommerce')) {
            echo '<div class="sidemenu-wrapper shopping-cart">';
                echo '<div class="sidemenu-content">';
                    echo '<button class="closeButton sideMenuCartClose"><i class="far fa-times"></i></button>';
                    echo '<div class="widget woocommerce widget_shopping_cart">';
                        echo '<h3 class="widget_title">'.esc_html__( 'Shopping cart', 'medova' ).'</h3>';
                        echo '<div class="widget_shopping_cart_content">';
                            if( class_exists( 'woocommerce' ) ){
                                 woocommerce_mini_cart();
                            }
                        echo '</div>';
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        }

    }
}

// mobile logo
function medova_mobile_logo() {
    $logo_url = medova_opt('medova_mobile_logo', 'url' );
    $mobile_menu = '';
    if( !empty($logo_url )){
        $mobile_menu = '<div class="mobile-logo"><a href="'.home_url('/').'"><img src="'.esc_url($logo_url).'" alt="'.esc_attr__( 'logo', 'medova' ).'"></a></div>';
    }else{
        $mobile_menu .= '<div class="mobile-logo">';
        $mobile_menu .= medova_theme_logo();
        $mobile_menu .= '</div>';
    }

    return $mobile_menu;
 }

//header Mobile Menu
if( ! function_exists( 'medova_mobile_menu' ) ){
    function medova_mobile_menu(){
    ?>
    <div class="th-menu-wrapper">
        <div class="th-menu-area text-center">
            <button class="th-menu-toggle"><i class="fal fa-times"></i></button>
            <?php  if( class_exists('ReduxFramework') ):?>
                <?php 
                    if(!empty(medova_opt('medova_menu_menu_show') )){
                        echo medova_mobile_logo(); 
                    }
                ?>
            <?php else: ?>
                <div class="mobile-logo">
                    <?php echo medova_theme_logo(); ?>
                </div>
            <?php endif; ?>
            <div class="th-mobile-menu">
                <?php 
                    if( has_nav_menu( 'primary-menu' ) ){
                        wp_nav_menu( array(
                            "theme_location"    => 'primary-menu',
                            "container"         => '',
                            "menu_class"        => ''
                        ) );
                    }
                ?>
            </div>
        </div>
    </div>

<?php
    }
}



// Blog post views function
function medova_setPostViews( $postID ) {
    $count_key  = 'post_views_count';
    $count      = get_post_meta( $postID, $count_key, true );
    if( $count == '' ){
        $count = 0;
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
    }else{
        $count++;
        update_post_meta( $postID, $count_key, $count );
    }
}

function medova_getPostViews( $postID ){
    $count_key  = 'post_views_count';
    $count      = get_post_meta( $postID, $count_key, true );
    if( $count == '' ){
        delete_post_meta( $postID, $count_key );
        add_post_meta( $postID, $count_key, '0' );
        return __( '0', 'medova' );
    }
    return $count;
}

add_filter( 'wp_list_categories', 'medova_cat_count_span' );
function medova_cat_count_span( $links ) {
    $links = str_replace('</a> (', '</a> <span class="category-number">', $links);
    $links = str_replace(')', '</span>', $links);
    return $links;
}

add_filter( 'get_archives_link', 'medova_archive_count_span' );
function medova_archive_count_span( $links ) {
    $links = str_replace('</a>&nbsp;(', '</a> <span class="category-number">', $links);
    $links = str_replace(')', '</span>', $links);
    return $links;
}

// Add Extra Class On Comment Reply Button
function medova_custom_comment_reply_link( $content ) {
    $extra_classes = 'reply-btn';
    return preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $extra_classes, $content);
}

add_filter('comment_reply_link', 'medova_custom_comment_reply_link', 99);

// Add Extra Class On Edit Comment Link
function medova_custom_edit_comment_link( $content ) {
    $extra_classes = 'reply-btn';
    return preg_replace( '/comment-edit-link/', 'comment-edit-link ' . $extra_classes, $content);
}

add_filter('edit_comment_link', 'medova_custom_edit_comment_link', 99);


function medova_post_classes( $classes, $class, $post_id ) {
    if ( get_post_type() === 'post' ) {
        $classes[] = "th-blog blog-single has-post-thumbnail";
    }elseif( get_post_type() === 'product' ){
        // Return Class
    }elseif( get_post_type() === 'page' ){
        $classes[] = "page--item";
    }
    
    return $classes;
}
add_filter( 'post_class', 'medova_post_classes', 10, 3 );

// Contact form 7
add_filter('wpcf7_autop_or_not', '__return_false');

function medova_register_block_styles() {
    if ( function_exists( 'register_block_style' ) ) {
        register_block_style(
            'core/quote',
            array(
                'name'         => 'blue-quote',
                'label'        => esc_html__( 'Blue Quote', 'medova' ),
                'is_default'   => false, // usually not recommended to override core default
                'inline_style' => '.wp-block-quote.is-style-blue-quote { color: blue; }',
            )
        );
    }
}
add_action( 'init', 'medova_register_block_styles' );