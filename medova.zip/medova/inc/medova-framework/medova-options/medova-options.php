<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    // This is your option name where all the Redux data is stored.
    $opt_name = "medova_opt";

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'redux_demo/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }


    $alowhtml = array(
        'p' => array(
            'class' => array()
        ),
        'span' => array()
    );


    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();

    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire 
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        // 'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => esc_html__( 'Medova Options', 'medova' ),
        'page_title'           => esc_html__( 'Medova Options', 'medova' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => true,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );


    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => esc_html__( 'Theme Information 1', 'medova' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'medova' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => esc_html__( 'Theme Information 2', 'medova' ),
            'content' => esc_html__( '<p>This is the tab content, HTML is allowed.</p>', 'medova' )
        )
    );
    Redux::set_help_tab( $opt_name, $tabs );

    // Set the help sidebar
    $content = esc_html__( '<p>This is the sidebar content, HTML is allowed.</p>', 'medova' );
    Redux::set_help_sidebar( $opt_name, $content );


    // -> START General Fields

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'General', 'medova' ),
        'id'               => 'medova_general',
        'customizer_width' => '450px',
        'icon'             => 'el el-cog',
        'fields'           => array(
            array(
                'id'    => 'theme_1',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Cursor Style', 'medova'),
            ),
            
            array(
                'id'    => 'theme_2',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Global Color', 'medova'),
            ),
            array(
                'id'       => 'medova_theme_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Theme Color', 'medova' ),
            ),
            array(
                'id'       => 'medova_heading_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Heading Color (H1-H6)', 'medova' ),
            ),
            array(
                'id'       => 'medova_body_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Body Color (Default Text Color)', 'medova' ),
            ),
            array(
                'id'       => 'medova_link_color',
                'type'     => 'link_color',
                'title'    => esc_html__( 'Links Color', 'medova' ), 
                'output'   => array( 'color'    =>  'a' ),
            ),
   
        )

    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Typography', 'medova' ),
        'id'               => 'medova_typography',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'medova_theme_body_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'Body Font Family', 'medova' ),
                'google'      => true, 
                'font-size' => false,
                'line-height' => false,
                'subsets' => false,
                'text-align' => false,
                'color' => false,
                'font-style' => false,
                'font-weight' => false,
                'output'      => array(''),
            ),
            array(
                'id'       => 'medova_theme_heading_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'Heading Font Family', 'medova' ),
                'google'      => true, 
                'font-size' => false,
                'line-height' => false,
                'subsets' => false,
                'text-align' => false,
                'color' => false,
                'font-style' => false,
                'font-weight' => false,
                'output'      => array(''),
            ),
            array(
                'id'    => 'info_11',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Heading Fonts', 'medova'),
            ),
            array(
                'id'       => 'medova_theme_h1_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H1 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h1'),
            ),
            array(
                'id'       => 'medova_theme_h2_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H2 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h2'),
            ),
            array(
                'id'       => 'medova_theme_h3_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H3 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h3'),
            ),
            array(
                'id'       => 'medova_theme_h4_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H4 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h4'),
            ),
            array(
                'id'       => 'medova_theme_h5_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H5 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h5'),
            ),
            array(
                'id'       => 'medova_theme_h6_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'H6 Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('h6'),
            ),
            array(
                'id'    => 'info_22',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Paragraph Fonts', 'medova'),
            ),
            array(
                'id'       => 'medova_theme_p_font',
                'type'     => 'typography',
                'title'    => esc_html__( 'P Font', 'medova' ),
                'google'      => true, 
                'font-style' => true,
                'text-transform' => true,
                'subsets' => false,
                'text-align' => false,
                'color' => true,
                'output'      => array('p'),
            ),
           
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Back To Top', 'medova' ),
        'id'               => 'medova_backtotop',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'medova_display_bcktotop',
                'type'     => 'switch',
                'title'    => esc_html__( 'Back To Top Button', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display back to top button.', 'medova' ),
                'default'  => true,
                'on'       => esc_html__( 'Enabled', 'medova' ),
                'off'      => esc_html__( 'Disabled', 'medova' ),
            ),
            array(
                'id'       => 'medova_bcktotop_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Color', 'medova' ),
                'required' => array('medova_display_bcktotop','equals','1'),
                'output'   => array( '--theme-color' =>'.scroll-top:after' ),
            ),
            array(
                'id'       => 'medova_bcktotop_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Background Color', 'medova' ),
                'required' => array('medova_display_bcktotop','equals','1'),
                'output'   => array( 'background-color' =>'.scroll-top svg' ),
            ),
            array(
                'id'       => 'medova_bcktotop_circle_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Circle Scroll Color', 'medova' ),
                'required' => array('medova_display_bcktotop','equals','1'),
                'output'   => array( '--theme-color' =>'.scroll-top .progress-circle path' ),
            ),
           
        )
    ) );

    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Preloader', 'medova' ),
        'id'               => 'medova_preloader',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'medova_display_preloader', 
                'type'     => 'switch',
                'title'    => esc_html__( 'Preloader', 'medova' ),
                'subtitle' => esc_html__( 'Switch Enabled to Display Preloader.', 'medova' ),
                'default'  => true,
                'on'       => esc_html__('Enabled','medova'),
                'off'      => esc_html__('Disabled','medova'),
            ),
            array(
                'title'     => esc_html__( 'Medova Preloader logo', 'medova' ),
                'id'        => 'medova_preloader_logo',
                'type'      => 'media',
            ),
            array(
                'id'       => 'medova_preloader_cancel_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Preloader Cancel Text', 'medova' ),
                'default'  => esc_html__( 'Cancel Preloader', 'medova' ),
                'subtitle' => esc_html__( 'Text for Preloader Cancel Button.', 'medova' ),
                'required' => array( 'medova_display_preloader', 'equals', '1' ),
            ),

        )
    ));

    /* End General Fields */

    /* Admin Lebel Fields */
    Redux::setSection( $opt_name, array(
        'title'             => esc_html__( 'Admin Label', 'medova' ),
        'id'                => 'medova_admin_label',
        'customizer_width'  => '450px',
        'subsection'        => true,
        'fields'            => array(
            array(
                'title'     => esc_html__( 'Admin Login Logo', 'medova' ),
                'subtitle'  => esc_html__( 'It belongs to the back-end of your website to log-in to admin panel.', 'medova' ),
                'id'        => 'medova_admin_login_logo',
                'type'      => 'media',
            ),
            array(
                'title'     => esc_html__( 'Custom CSS For admin', 'medova' ),
                'subtitle'  => esc_html__( 'Any CSS your write here will run in admin.', 'medova' ),
                'id'        => 'medova_theme_admin_custom_css',
                'type'      => 'ace_editor',
                'mode'      => 'css',
                'theme'     => 'chrome',
                'full_width'=> true,
            ),
        ),
    ) );

    // -> START Basic Fields
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header', 'medova' ),
        'id'               => 'medova_header',
        'customizer_width' => '400px',
        'icon'             => 'el el-credit-card',
        'fields'           => array(
            array(
                'id'       => 'medova_header_options',
                'type'     => 'button_set',
                'default'  => '1',
                'options'  => array(
                    "1"   => esc_html__('Prebuilt','medova'),
                    "2"      => esc_html__('Header Builder','medova'),
                ),
                'title'    => esc_html__( 'Header Options', 'medova' ),
                'subtitle' => esc_html__( 'Select header options.', 'medova' ),
            ),
            array(
                'id'       => 'medova_header_select_options',
                'type'     => 'select',
                'data'     => 'posts',
                'args'     => array(
                    'post_type'     => 'medova_header',
                    'posts_per_page' => -1,
                ),
                'title'    => esc_html__( 'Header', 'medova' ),
                'subtitle' => esc_html__( 'Select header.', 'medova' ),
                'required' => array( 'medova_header_options', 'equals', '2' )
            ),
            array(
                'id'       => 'medova_btn_text',
                'type'     => 'text',
                'validate' => 'html',
                'default'  => esc_html__( 'Request a quote', 'medova' ),
                'title'    => esc_html__( 'Button Text', 'medova' ),
                'required' => array( 'medova_header_options', 'equals', '1' ),
            ),
            array(
                'id'       => 'medova_btn_url',
                'type'     => 'text',
                'default'  => esc_html__( '#', 'medova' ),
                'title'    => esc_html__( 'Button URL?', 'medova' ),
                'required' => array( 'medova_header_options', 'equals', '1' ),
            ),
            array(
                'id'       => 'medova_offcanvas',
                'type'     => 'switch',
                'title'    => esc_html__( 'Offcanvas ON/OFF', 'medova' ),
                'subtitle' => esc_html__( 'ON / OFF ( Default settings ON ).', 'medova' ),
                'default'  => '1',
                'on'       => 'ON',
                'off'      => 'OFF',
            ),
          
        ),
    ) );
    // -> END Basic Fields

    // -> START Header Logo
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header Logo', 'medova' ),
        'id'               => 'medova_header_logo_option',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'medova_site_logo',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Logo', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your site logo for header ( recommendation png format ).', 'medova' ),
            ),
            array(
                'id'       => 'medova_site_logo_dimensions',
                'type'     => 'dimensions',
                'units'    => array('px'),
                'title'    => esc_html__('Logo Dimensions (Width/Height).', 'medova'),
                'output'   => array('.header-logo .logo img'),
                'subtitle' => esc_html__('Set logo dimensions to choose width, height, and unit.', 'medova'),
            ),
            array(
                'id'       => 'medova_site_logomargin_dimensions',
                'type'     => 'spacing',
                'mode'     => 'margin',
                'output'   => array('.header-logo .logo img'),
                'units_extended' => 'false',
                'units'    => array('px'),
                'title'    => esc_html__('Logo Top and Bottom Margin.', 'medova'),
                'left'     => false,
                'right'    => false,
                'subtitle' => esc_html__('Set logo top and bottom margin.', 'medova'),
                'default'            => array(
                    'units'           => 'px'
                )
            ),
            array(
                'id'       => 'medova_text_title',
                'type'     => 'text',
                'validate' => 'html',
                'title'    => esc_html__( 'Text Logo', 'medova' ),
                'subtitle' => esc_html__( 'Write your logo text use as logo ( You can use span tag for text color ).', 'medova' ),
            )
        )
    ) );
    // -> End Header Logo

    // -> START Header Menu
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Header Style', 'medova' ),
        'id'               => 'medova_header_menu_option',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'    => 'sticky_info',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Header Sticky On/Off', 'medova'),
            ),
            array(
                'id'       => 'medova_header_sticky',
                'type'     => 'switch',
                'title'    => esc_html__( 'Header Sticky ON/OFF', 'medova' ),
                'subtitle' => esc_html__( 'ON / OFF Header Sticky ( Default settings ON ).', 'medova' ),
                'default'  => '1',
                'on'       => 'ON',
                'off'      => 'OFF',
            ),
            array( 
                'id'    => 'info_2',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Background', 'medova'),
            ),
            array(
                'id'       => 'medova_menu_icon',
                'type'     => 'switch',
                'title'    => esc_html__( 'Navbar Sub-menu Icon Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show menu icon ( Default settings SHOW ).', 'medova' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
            array(
                'id'       => 'medova_menu_icon_class',
                'type'     => 'text',
                'validate' => 'html',
                'default'  => esc_html__( 'e00d', 'medova' ),
                'title'    => esc_html__( 'Sub Menu Icon', 'medova' ),
                'subtitle' => esc_html__( 'If you change icon need to use Font-Awesome Unicode icon ( Example: f0c9 | e00d ).', 'medova' ),
                'required' => array( 'medova_menu_icon', 'equals', '1' )
            ),
            
            array(
                'id'       => 'medova_header_menu_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Menu Color', 'medova' ),
                'output'   => array( 'color'    =>  '.prebuilt .main-menu>ul>li>a' ),
            ),
            array(
                'id'       => 'medova_header_menu_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu Hover Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Menu Hover Color', 'medova' ),
                'output'   => array( 'color'    =>  '.prebuilt .main-menu>ul>li>a:hover' ),
            ),
            array(
                'id'       => 'medova_header_submenu_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Submenu Color', 'medova' ),
                'output'   => array( 'color'    =>  '.prebuilt .main-menu ul.sub-menu li a' ),
            ),
            array(
                'id'       => 'medova_header_submenu_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Hover Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Submenu Hover Color', 'medova' ),
                'output'   => array( 'color'    =>  '.prebuilt .main-menu ul.sub-menu li a:hover' ),
            ),
            array(
                'id'       => 'medova_header_submenu_icon_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Submenu Icon Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Icon Hover Color', 'medova' ),
                'output'   => array( 'color'    =>  '.prebuilt .main-menu ul.sub-menu li a:before, .prebuilt .main-menu ul li.menu-item-has-children > a:after' ),
            ),
            
        )
    ) );
    // -> End Header Menu

     // -> START Mobile Menu
     Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Mobile Menu', 'medova' ), 
        'id'               => 'medova_mobile_menu_option',
        'subsection'       => true,
        'fields'           => array(
            array(
                'id'       => 'medova_menu_menu_show',
                'type'     => 'switch',
                'title'    => esc_html__( 'Mobile Logo Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show mobile menu logo ( Default settings SHOW ).', 'medova' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
            array(
                'id'       => 'medova_mobile_logo', 
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Logo', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your mobile logo for mobile menu ( recommendation png format ).', 'medova' ),
                'required' => array( 
                    array('medova_menu_menu_show','equals','1') 
                )
            ),
            array(
                'id'       => 'medova_mobile_logo_dimensions',
                'type'     => 'dimensions',
                'units'    => array('px'),
                'title'    => esc_html__('Logo Dimensions (Width/Height).', 'medova'),
                'output'   => array('.th-menu-wrapper .mobile-logo img'),
                'subtitle' => esc_html__('Set logo dimensions to choose width, height, and unit.', 'medova'),
                'required' => array( 
                    array('medova_menu_menu_show','equals','1') 
                )
            ),
            array(
                'id'       => 'medova_mobile_menu_bg',
                'type'     => 'color',
                'title'    => esc_html__( 'Logo Background', 'medova' ),
                'subtitle' => esc_html__( 'Set logo backgorund', 'medova' ),
                'output'   => array( 'background-color'    =>  '.th-menu-wrapper .mobile-logo' ),
                'required' => array( 
                    array('medova_menu_menu_show','equals','1') 
                )
            ),
    
        )
    ) );
    // -> End Mobile Menu

    // -> START Blog Page
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Blog', 'medova' ),
        'id'         => 'medova_blog_page',
        'icon'  => 'el el-blogger',
        'fields'     => array(

            array(
                'id'       => 'medova_blog_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Blog Page Layout', 'medova' ),
                'subtitle' => esc_html__( 'Choose blog layout from here. If you use this option then you will able to change three type of blog layout ( Default Left Sidebar Layour ). ', 'medova' ),
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'medova_blog_grid',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Blog Post Column', 'medova' ),
                'subtitle' => esc_html__( 'Select your blog post column from here. If you use this option then you will able to select three type of blog post layout ( Default Two Column ).', 'medova' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/1column.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2column.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3column.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'medova_blog_page_title_switcher',
                'type'     => 'switch',
                'default'  => 1,
                'on'       => esc_html__('Show','medova'),
                'off'      => esc_html__('Hide','medova'),
                'title'    => esc_html__('Blog Page Title', 'medova'),
                'subtitle' => esc_html__('Control blog page title show / hide. If you use this option then you will able to show / hide your blog page title ( Default Setting Show ).', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_page_title_setting',
                'type'     => 'button_set',
                'title'    => esc_html__('Blog Page Title Setting', 'medova'),
                'subtitle' => esc_html__('Control blog page title setting. If you use this option then you can able to show default or custom blog page title ( Default Blog ).', 'medova'),
                'options'  => array(
                    "predefine"   => esc_html__('Default','medova'),
                    "custom"      => esc_html__('Custom','medova'),
                ),
                'default'  => 'predefine',
                'required' => array("medova_blog_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'medova_blog_page_custom_title',
                'type'     => 'text',
                'title'    => esc_html__('Blog Custom Title', 'medova'),
                'subtitle' => esc_html__('Set blog page custom title form here. If you use this option then you will able to set your won title text.', 'medova'),
                'required' => array('medova_blog_page_title_setting','equals','custom')
            ),
            array(
                'id'            => 'medova_blog_postExcerpt',
                'type'          => 'slider',
                'title'         => esc_html__('Blog Posts Excerpt', 'medova'),
                'subtitle'      => esc_html__('Control the number of characters you want to show in the blog page for each post.. If you use this option then you can able to control your blog post characters from here ( Default show 10 ).', 'medova'),
                "default"       => 28,
                "min"           => 0,
                "step"          => 1,
                "max"           => 100,
                'resolution'    => 1,
                'display_value' => 'text',
            ),
            array(
                'id'       => 'medova_blog_readmore_setting',
                'type'     => 'button_set',
                'title'    => esc_html__( 'Read More Text Setting', 'medova' ),
                'subtitle' => esc_html__( 'Control read more text from here.', 'medova' ),
                'options'  => array(
                    "default"   => esc_html__('Default','medova'),
                    "custom"    => esc_html__('Custom','medova'),
                ),
                'default'  => 'default',
            ),
            array(
                'id'       => 'medova_blog_custom_readmore',
                'type'     => 'text',
                'title'    => esc_html__('Read More Text', 'medova'),
                'subtitle' => esc_html__('Set read moer text here. If you use this option then you will able to set your won text.', 'medova'),
                'required' => array('medova_blog_readmore_setting','equals','custom')
            ),
            array(
                'id'       => 'medova_blog_title_color',
                'output'   => array( '.th-blog .blog-title a'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Title Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Blog Title Color.', 'medova' ),
            ),
            array(
                'id'       => 'medova_blog_title_hover_color',
                'output'   => array( '.th-blog .blog-title a:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Title Hover Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Blog Title Hover Color.', 'medova' ),
            ),
            array(
                'id'       => 'medova_blog_contant_color',
                'output'   => array( '.th-blog .blog-content p'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Excerpt / Content Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Blog Excerpt / Content Color.', 'medova' ),
            ),
            array(
                'id'    => 'blog_info_1',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Button', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_read_more_button_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Color', 'medova' ),
                'output'    => array(
                    '--theme-color' => '.blog-single .blog-content .th-btn.style-border2', 
                ),
            ),
            array(
                'id'       => 'medova_blog_read_more_button_color2',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Hover Color', 'medova' ),
                'output'    => array(
                    '--title-color' => '.blog-single .blog-content .th-btn.style-border2:hover', 
                ),
            ),
            array(
                'id'    => 'blog_info_2',
                'type'  => 'info',
                'style' => 'success',
                'title' => __('Pagination', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_pagination_color',
                'output'   => array( '.th-pagination a'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Color', 'medova'),
                'subtitle' => esc_html__('Set Blog Pagination Color.', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_pagination_bg_color',
                'output'   => array( 'background-color' => '.th-pagination a'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Background', 'medova'),
                'subtitle' => esc_html__('Set Blog Pagination Backgorund Color.', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_pagination_hover_color',
                'output'   => array( '.th-pagination a:hover, .th-pagination a.active'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Hover & Active Color', 'medova'),
                'subtitle' => esc_html__('Set Blog Pagination Hover & Active Color.', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_pagination_bg_hover_color',
                'output'   => array( '--theme-color' => '.th-pagination a:hover, .th-pagination a.active'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Pagination Hover & Active Background', 'medova'),
                'subtitle' => esc_html__('Set Blog Pagination Background Hover & Active Color.', 'medova'),
            ),
        ),
    ) );

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Single Blog Page', 'medova' ),
        'id'         => 'medova_post_detail_styles',
        'subsection' => true,
        'fields'     => array(

            array(
                'id'       => 'medova_blog_single_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Layout', 'medova' ),
                'subtitle' => esc_html__( 'Choose blog single page layout from here. If you use this option then you will able to change three type of blog single page layout ( Default Left Sidebar Layour ). ', 'medova' ),
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'medova_post_details_title_position',
                'type'     => 'button_set',
                'default'  => 'header',
                'options'  => array(
                    'header'        => esc_html__('On Header','medova'),
                    'below'         => esc_html__('Below Thumbnail','medova'),
                ),
                'title'    => esc_html__('Blog Post Title Position', 'medova'),
                'subtitle' => esc_html__('Control blog post title position from here.', 'medova'),
            ),
            array(
                'id'       => 'medova_post_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__('Blog Details Custom Title', 'medova'),
                'subtitle' => esc_html__('This title will show in Breadcrumb title.', 'medova'),
                'required' => array('medova_post_details_title_position','equals','below')
            ),
            array(
                'id'       => 'medova_display_post_tags',
                'type'     => 'switch',
                'title'    => esc_html__( 'Tags', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display Tags.', 'medova' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_post_details_share_options',
                'type'     => 'switch',
                'title'    => esc_html__('Share Options', 'medova'),
                'subtitle' => esc_html__('Control post share options from here. If you use this option then you will able to show or hide post share options.', 'medova'),
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
                'default'   => '0',
            ),
            array(
                'id'       => 'medova_post_details_author_box',
                'type'     => 'switch',
                'title'    => esc_html__('Author Box', 'medova'),
                'subtitle' => esc_html__('Switch On to Display Author Box. Set author bio & social links', 'medova'),
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
                'default'  => true,
            ),
            array(
                'id'       => 'medova_post_details_post_navigation',
                'type'     => 'switch',
                'title'    => esc_html__('Post Navigation', 'medova'),
                'subtitle' => esc_html__('Switch On to Display Post Navigation.', 'medova'),
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
                'default'  => true, 
            ),
           
        )
    ));

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Meta Data', 'medova' ),
        'id'         => 'medova_common_meta_data',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'medova_display_post_author',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post author', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Author.', 'medova' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_display_post_date',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Date', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Date.', 'medova' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_display_post_comments',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Comment', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Comment Number.', 'medova' ),
                'default'  => true,
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_display_post_cate',
                'type'     => 'switch',
                'title'    => esc_html__( 'Post Category', 'medova' ),
                'subtitle' => esc_html__( 'Switch On to Display Post Category.', 'medova' ),
                'default'  => false,
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_blog_meta_icon_color',
                'output'   => array( '.blog-meta a i'),
                'type'     => 'color',
                'title'    => esc_html__('Blog Meta Icon Color', 'medova'),
                'subtitle' => esc_html__('Set Blog Meta Icon Color.', 'medova'),
            ),
            array(
                'id'       => 'medova_blog_meta_text_color',
                'output'   => array( '.blog-meta a,.blog-meta span'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Meta Text Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Blog Meta Text Color.', 'medova' ),
            ),
            array(
                'id'       => 'medova_blog_meta_text_hover_color',
                'output'   => array( '.blog-meta a:hover'),
                'type'     => 'color',
                'title'    => esc_html__( 'Blog Meta Hover Text Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Blog Meta Hover Text Color.', 'medova' ),
            ),
        )
    ));

    /* End blog Page */

    // -> START Page Option
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Page & Breadcrumb', 'medova' ),
        'id'         => 'medova_page_page',
        'icon'  => 'el el-file',
        'fields'     => array(
            array(
                'id'       => 'medova_page_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select layout', 'medova' ),
                'subtitle' => esc_html__( 'Choose your page layout. If you use this option then you will able to choose three type of page layout ( Default no sidebar ). ', 'medova' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'medova_page_layoutopt',
                'type'     => 'button_set',
                'title'    => esc_html__('Sidebar Settings', 'medova'),
                'subtitle' => esc_html__('Set page sidebar. If you use this option then you will able to set three type of sidebar ( Default no sidebar ).', 'medova'),
                //Must provide key => value pairs for options
                'options' => array(
                    '1' => esc_html__( 'Page Sidebar', 'medova' ),
                    '2' => esc_html__( 'Blog Sidebar', 'medova' )
                 ),
                'default' => '1',
                'required'  => array('medova_page_sidebar','!=','1')
            ),
            array(
                'id'       => 'medova_page_title_switcher',
                'type'     => 'switch',
                'title'    => esc_html__('Title', 'medova'),
                'subtitle' => esc_html__('Switch enabled to display page title. Fot this option you will able to show / hide page title.  Default setting Enabled', 'medova'),
                'default'  => '1',
                'on'        => esc_html__('Enabled','medova'),
                'off'       => esc_html__('Disabled','medova'),
            ),
            array(
                'id'       => 'medova_page_title_tag',
                'type'     => 'select',
                'options'  => array(
                    'h1'        => esc_html__('H1','medova'),
                    'h2'        => esc_html__('H2','medova'),
                    'h3'        => esc_html__('H3','medova'),
                    'h4'        => esc_html__('H4','medova'),
                    'h5'        => esc_html__('H5','medova'),
                    'h6'        => esc_html__('H6','medova'),
                ),
                'default'  => 'h1',
                'title'    => esc_html__( 'Title Tag', 'medova' ),
                'subtitle' => esc_html__( 'Select page title tag. If you use this option then you can able to change title tag H1 - H6 ( Default tag H1 )', 'medova' ),
                'required' => array("medova_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'medova_allHeader_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Title Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Title Color', 'medova' ),
                'output'   => array( 'color' => '.breadcumb-title' ),
                'required' => array("medova_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'medova_allHeader_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Text Color', 'medova' ),
                'subtitle' => esc_html__( 'Set Color', 'medova' ),
                'output'   => array( '--white-color' => '.breadcumb-content' ),
                'required' => array("medova_page_title_switcher","equals","1")
            ),
            array(
                'id'       => 'medova_allHeader_spacing',
                'type'     => 'spacing',
                'mode'     => 'padding',
                'output'   => array('.breadcumb-wrapper'),
                'units_extended' => 'false',
                'units'    => array('px'),
                'title'    => esc_html__('Breadcrumb Top and Bottom Margin.', 'medova'),
                'left'     => false,
                'right'    => false,
                'default'            => array(
                    'units'           => 'px'
                )
            ),
            array(
                'id'       => 'medova_allHeader_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background', 'medova' ),
                'subtitle' => esc_html__( 'Setting page header background. If you use this option then you will able to set Background Color, Background Image, Background Repeat, Background Size, Background Attachment, Background Position.', 'medova' ),
                'output'   => array( 'background' => '.breadcumb-wrapper' ),
            ),
             array(
                'id'       => 'medova_shoppage_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background For Shop Pages', 'medova' ),
                'output'   => array( 'background' => '.custom-woo-class' ),
            ),
            array(
                'id'       => 'medova_archivepage_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background For Archive Pages', 'medova' ),
                'output'   => array( 'background' => '.custom-archive-class' ),
            ),
            array(
                'id'       => 'medova_searchpage_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background For Search Pages', 'medova' ),
                'output'   => array( 'background' => '.custom-search-class' ),
            ),
            array(
                'id'       => 'medova_errorpage_bg',
                'type'     => 'background',
                'title'    => esc_html__( 'Background For Error Pages', 'medova' ),
                'output'   => array( 'background' => '.custom-error-class' ),
            ),
            array(
                'id'       => 'medova_enable_breadcrumb',
                'type'     => 'switch',
                'title'    => esc_html__( 'Breadcrumb Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show breadcrumb from all pages and posts ( Default settings hide ).', 'medova' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),
            array(
                'id'       => 'medova_allHeader_breadcrumbtextcolor',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Color', 'medova' ),
                'subtitle' => esc_html__( 'Choose page header breadcrumb text color here.If you user this option then you will able to set page breadcrumb color.', 'medova' ),
                'required' => array("medova_enable_breadcrumb","equals","1"),
                'output'   => array( 'color' => '.breadcumb-wrapper .breadcumb-content ul li a' ),
            ),
            array(
                'id'       => 'medova_allHeader_breadcrumbtextactivecolor',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Active Color', 'medova' ),
                'subtitle' => esc_html__( 'Choose page header breadcrumb text active color here.If you user this option then you will able to set page breadcrumb active color.', 'medova' ),
                'required' => array( "medova_enable_breadcrumb", "equals", "1" ),
                'output'   => array( 'color' => '.breadcumb-wrapper .breadcumb-content ul li:last-child' ),
            ),
            array(
                'id'       => 'medova_allHeader_dividercolor',
                'type'     => 'color',
                'title'    => esc_html__( 'Breadcrumb Divider Color', 'medova' ),
                'subtitle' => esc_html__( 'Choose breadcrumb divider color.', 'medova' ),
                'required' => array( "medova_enable_breadcrumb", "equals", "1" ),
                'output'   => array( 'color'=>'.breadcumb-wrapper .breadcumb-content ul li:after' ),
            ),
        ),
    ) );
    /* End Page option */











    // -> START Footer Media
    Redux::setSection( $opt_name , array(
       'title'            => esc_html__( 'Lisitng', 'medova' ),
       'id'               => 'medova_listing',
       'desc'             => esc_html__( 'Lisitng Overview', 'medova' ),
       'customizer_width' => '400px',
       'icon'              => 'el el-photo',
   ) );

   Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Listing Archive Page', 'medova' ),
        'id'         => 'medova_lisitng_section',
        'subsection' => true,
        'fields'     => array(

            array(
                'id'       => 'medova_listing_archive',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Select layout', 'medova' ),
                'subtitle' => esc_attr__( 'Choose your page layout. If you use Default style then you can do all modification from Directory Plugin', 'medova' ),

                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    'default' => array(
                        'alt' => esc_attr__('Default Style','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/default.png')
                    ),
                    'own' => array(
                        'alt' => esc_attr__('Theme Own Style','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/theme.png')
                    ),
                    

                ),
                'default'  => 'own'
            ),

            array(
                'id'       => 'medova_single_listing_comments',
                'type'     => 'switch',
                'title'    => esc_html__( 'Comments Area Hide/Show', 'medova' ),
                'default'  => '1',
                'on'       => 'Show',
                'off'      => 'Hide',
            ),

            array(
                'id'       => 'medova_single_listing_comments_label',
                'type'     => 'text',
                'title'    => esc_html__( 'Comments Label', 'medova' ),
                'default'  => esc_html__( 'Property Review', 'medova' ),
                'required' => array( "medova_single_listing_comments", "equals", "1" ),
            ),

            
            array(
                'id'       => 'medova_listing_readmore',
                'type'     => 'text',
                'title'    => esc_html__( 'Button Text', 'medova' ),
                'default'  => esc_html__( 'Read More', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_bed_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Bed Label', 'medova' ),
                'default'  => esc_html__( 'Bed', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_bed_icon',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Bed Icon', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your icon image ( recommendation png or svg format ).', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_bath_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Bath Label', 'medova' ),
                'default'  => esc_html__( 'Bath', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_bath_icon',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Bath Icon', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your icon image ( recommendation png or svg format ).', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_sqft_text',
                'type'     => 'text',
                'title'    => esc_html__( 'sqft Label', 'medova' ),
                'default'  => esc_html__( 'sqft', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),
            array(
                'id'       => 'medova_listing_sqft_icon',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'sqft Icon', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your icon image ( recommendation png or svg format ).', 'medova' ),
                'required' => array( "medova_listing_archive", "equals", "own" ),
            ),

            
            
            

        ),
    ) );


    // -> START Footer Bottom
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer Bottom', 'medova' ),
        'id'         => 'medova_footer_bottom000000000',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'medova_disable_footer_bottom0000000000',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Bottom?', 'medova' ),
                'default'  => 1,
                'on'       => esc_html__('Enabled','medova'),
                'off'      => esc_html__('Disable','medova'),

            ),
            

        )
    ));

    /* End Footer Media */





    // -> START 404 Page

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( '404 Page', 'medova' ),
        'id'         => 'medova_404_page',
        'icon'       => 'el el-ban-circle',
        'fields'     => array(
            array(
                'id'       => 'medova_error_img',
                'type'     => 'media',
                'url'      => true,
                'title'    => esc_html__( 'Error Image', 'medova' ),
                'compiler' => 'true',
                'subtitle' => esc_html__( 'Upload your error image ( recommendation png or svg format ).', 'medova' ),
            ),
            array(
                'id'       => 'medova_error_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Page Title', 'medova' ),
                'default'  => esc_html__( 'Sorry! Page did not found', 'medova' ),
            ),
            array(
                'id'       => 'medova_error_subtitle',
                'type'     => 'text',
                'title'    => esc_html__( 'SubTitle', 'medova' ),
                'default'  => esc_html__( 'Sorry! Page did not found', 'medova' ),
            ),
            array(
                'id'       => 'medova_error_title_color',
                'type'     => 'color',
                'output'   => array( '.error-title' ),
                'title'    => esc_html__( 'Title Color', 'medova' ),
                'validate' => 'color'
            ), 
           
            array(
                'id'       => 'medova_error_btn_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Button Text', 'medova' ),
                'default'  => esc_html__( 'Return To Home', 'medova' ),
            ),
            array(
                'id'       => 'medova_error_btn_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Color', 'medova' ),
                'output'   => array( 'color'    =>  '.th-btn.error-btn' ),
            ),
            array(
                'id'       => 'medova_error_btn_bg_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Background', 'medova' ),
                'output'   => array( '--theme-color'    =>  '.th-btn.error-btn' ),
            ),
            array(
                'id'       => 'medova_error_btn_color2',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Hover Color', 'medova' ),
                'output'   => array( 'color'    =>  '.th-btn.error-btn:hover' ),
            ),
            array(
                'id'       => 'medova_error_btn_bg_color2',
                'type'     => 'color',
                'title'    => esc_html__( 'Button Hover Background', 'medova' ),
                'output'   => array( '--title-color'    =>  '.th-btn.error-btn:before, .th-btn.error-btn:after' ),
            ),

        ),
    ) );

    /* End 404 Page */
    // -> START Woo Page Option

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Woocommerce Page', 'medova' ),
        'id'         => 'medova_woo_page_page',
        'icon'  => 'el el-shopping-cart',
        'fields'     => array(
            array(
                'id'       => 'medova_shop_container',
                'type'     => 'switch',
                'title'    => esc_html__( 'Shop Page Container set', 'medova' ),
                'subtitle' => esc_html__( 'Set shop page layout container or full-width', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__('Container','medova'),
                'off'      => esc_html__('Full-Width','medova')
            ),
            array(
                'id'       => 'medova_woo_shoppage_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Set Shop Page Sidebar.', 'medova' ),
                'subtitle' => esc_html__( 'Choose shop page sidebar', 'medova' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'medova_woo_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Product Column', 'medova' ),
                'subtitle' => esc_html__( 'Set your woocommerce product column.', 'medova' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '2' => array(
                        'alt' => esc_attr__('2 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('3 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '4' => array(
                        'alt' => esc_attr__('4 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '6' => array(
                        'alt' => esc_attr__('6 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/6col.png')
                    ),
                ),
                'default'  => '4'
            ),
            array(
                'id'       => 'medova_woo_product_perpage',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Per Page', 'medova' ),
                'default' => '12'
            ),
            array(
                'id'       => 'medova_single_shop_container',
                'type'     => 'switch',
                'title'    => esc_html__( 'Single Product Container set', 'medova' ),
                'subtitle' => esc_html__( 'Set single product page layout container or full-width', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__('Container','medova'),
                'off'      => esc_html__('Full-Width','medova')
            ),
            array(
                'id'       => 'medova_woo_singlepage_sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Product Single Page sidebar', 'medova' ),
                'subtitle' => esc_html__( 'Choose product single page sidebar.', 'medova' ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '1' => array(
                        'alt' => esc_attr__('1 Column','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/no-sideber.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('2 Column Left','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/left-sideber.png')
                    ),
                    '3' => array(
                        'alt' => esc_attr__('2 Column Right','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/right-sideber.png' )
                    ),

                ),
                'default'  => '1'
            ),
            array(
                'id'       => 'medova_product_details_title_position',
                'type'     => 'button_set',
                'default'  => 'below',
                'options'  => array(
                    'header'        => esc_html__('On Header','medova'),
                    'below'         => esc_html__('Below Thumbnail','medova'),
                ),
                'title'    => esc_html__('Product Details Title Position', 'medova'),
                'subtitle' => esc_html__('Control product details title position from here.', 'medova'),
            ),
            array(
                'id'       => 'medova_product_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Details Title', 'medova' ),
                'default'  => esc_html__( 'Shop Details', 'medova' ),
                'required' => array('medova_product_details_title_position','equals','below'),
            ),
            array(
                'id'       => 'medova_product_details_custom_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Product Details Title', 'medova' ),
                'default'  => esc_html__( 'Shop Details', 'medova' ),
                'required' => array('medova_product_details_title_position','equals','below'),
            ),
            array(
                'id'       => 'medova_woo_relproduct_display',
                'type'     => 'switch',
                'title'    => esc_html__( 'Related product Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show related product in single page (Default Settings Show)', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__('Show','medova'),
                'off'      => esc_html__('Hide','medova')
            ),
            array(
                'id'       => 'medova_woo_relproduct_subtitle',
                'type'     => 'text',
                'title'    => esc_html__( 'Related products Subtitle', 'medova' ),
                'default'  => esc_html__( 'Similar Products', 'medova' ),
                'required' => array('medova_woo_relproduct_display','equals',true),
            ),
            array(
                'id'       => 'medova_woo_relproduct_title',
                'type'     => 'text',
                'title'    => esc_html__( 'Related products Title', 'medova' ),
                'default'  => esc_html__( 'Related products', 'medova' ),
                'required' => array('medova_woo_relproduct_display','equals',true),
            ),
            array(
                'id'       => 'medova_woo_relproduct_slider', 
                'type'     => 'switch',
                'title'    => esc_html__( 'Related product Sldier On/Off', 'medova' ),
                'subtitle' => esc_html__( 'Slider On/Off related product slider in single page (Default Settings Slider On)', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__('Slider On','medova'),
                'off'      => esc_html__('Slider Off','medova'),
                'required' => array('medova_woo_relproduct_display','equals',true),
            ),
            array(
                'id'       => 'medova_woo_relproduct_slider_arrow', 
                'type'     => 'switch',
                'title'    => esc_html__( 'Related product Sldier Arrow On/Off', 'medova' ),
                'subtitle' => esc_html__( 'Slider arrow On/Off related product slider in single page (Default Settings Slider On)', 'medova' ),
                'default'  => '0',
                'on'       => esc_html__('Arrow On','medova'),
                'off'      => esc_html__('Arrow Off','medova'),
                'required' => array('medova_woo_relproduct_slider','equals',true),
            ),
            array(
                'id'       => 'medova_woo_relproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Related products number', 'medova' ),
                'subtitle' => esc_html__( 'Set how many related products you want to show in single product page.', 'medova' ),
                'default'  => 5,
                'required' => array('medova_woo_relproduct_display','equals',true)
            ),

            array(
                'id'       => 'medova_woo_related_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Related Product Column', 'medova' ),
                'subtitle' => esc_html__( 'Set your woocommerce related product column. it works if slider is off', 'medova' ),
                'required' => array('medova_woo_relproduct_display','equals',true),
                'required' => array('medova_woo_relproduct_slider','equals',false),
                'options'  => array(
                    '6' => array(
                        'alt' => esc_attr__('2 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '4' => array(
                        'alt' => esc_attr__('3 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '3' => array(
                        'alt' => esc_attr__('4 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('6 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '3'
            ),
            array(
                'id'       => 'medova_woo_upsellproduct_display',
                'type'     => 'switch',
                'title'    => esc_html__( 'Upsell product Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show upsell product in single page (Default Settings Show)', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__('Show','medova'),
                'off'      => esc_html__('Hide','medova'),
            ),
            array(
                'id'       => 'medova_woo_upsellproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Upsells products number', 'medova' ),
                'subtitle' => esc_html__( 'Set how many upsells products you want to show in single product page.', 'medova' ),
                'default'  => 3,
                'required' => array('medova_woo_upsellproduct_display','equals',true),
            ),

            array(
                'id'       => 'medova_woo_upsell_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Upsells Product Column', 'medova' ),
                'subtitle' => esc_html__( 'Set your woocommerce upsell product column.', 'medova' ),
                'required' => array('medova_woo_upsellproduct_display','equals',true),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '6' => array(
                        'alt' => esc_attr__('2 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '4' => array(
                        'alt' => esc_attr__('3 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '3' => array(
                        'alt' => esc_attr__('4 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('6 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '4'
            ),
            array(
                'id'       => 'medova_woo_crosssellproduct_display',
                'type'     => 'switch',
                'title'    => esc_html__( 'Cross sell product Hide/Show', 'medova' ),
                'subtitle' => esc_html__( 'Hide / Show cross sell product in single page (Default Settings Show)', 'medova' ),
                'default'  => '1',
                'on'       => esc_html__( 'Show', 'medova' ),
                'off'      => esc_html__( 'Hide', 'medova' ),
            ),
            array(
                'id'       => 'medova_woo_crosssellproduct_num',
                'type'     => 'text',
                'title'    => esc_html__( 'Cross sell products number', 'medova' ),
                'subtitle' => esc_html__( 'Set how many cross sell products you want to show in single product page.', 'medova' ),
                'default'  => 3,
                'required' => array('medova_woo_crosssellproduct_display','equals',true),
            ),

            array(
                'id'       => 'medova_woo_crosssell_product_col',
                'type'     => 'image_select',
                'title'    => esc_html__( 'Cross sell Product Column', 'medova' ),
                'subtitle' => esc_html__( 'Set your woocommerce cross sell product column.', 'medova' ),
                'required' => array( 'medova_woo_crosssellproduct_display', 'equals', true ),
                //Must provide key => value(array:title|img) pairs for radio options
                'options'  => array(
                    '6' => array(
                        'alt' => esc_attr__('2 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri() .'/assets/img/2col.png')
                    ),
                    '4' => array(
                        'alt' => esc_attr__('3 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/3col.png' )
                    ),
                    '3' => array(
                        'alt' => esc_attr__('4 Columns','medova'),
                        'img' => esc_url( get_template_directory_uri(). '/assets/img/4col.png')
                    ),
                    '2' => array(
                        'alt' => esc_attr__('6 Columns','medova'),
                        'img' => esc_url(  get_template_directory_uri() .'/assets/img/6col.png' )
                    ),

                ),
                'default'  => '4'
            ),
        ),
    ) );

    /* End Woo Page option */
    // -> START Gallery
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Gallery', 'medova' ),
        'id'         => 'medova_gallery_widget',
        'icon'       => 'el el-gift',
        'fields'     => array(
            array(
                'id'          => 'medova_gallery_image_widget',
                'type'        => 'slides',
                'title'       => esc_html__('Add Gallery Image', 'medova'),
                'subtitle'    => esc_html__('Add gallery Image and url.', 'medova'),
                'show'        => array(
                    'title'          => false,
                    'description'    => false,
                    'progress'       => false,
                    'icon'           => false,
                    'facts-number'   => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'url'            => true,
                    'project-button' => false,
                    'image_upload'   => true,
                ),
            ),
        ),
    ) );
    // -> START Subscribe
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Subscribe', 'medova' ),
        'id'         => 'medova_subscribe_page',
        'icon'       => 'el el-eject',
        'fields'     => array(

            array(
                'id'       => 'medova_subscribe_apikey',
                'type'     => 'text',
                'title'    => esc_html__( 'Mailchimp API Key', 'medova' ),
                'subtitle' => esc_html__( 'Set mailchimp api key.', 'medova' ),
            ),
            array(
                'id'       => 'medova_subscribe_listid',
                'type'     => 'text',
                'title'    => esc_html__( 'Mailchimp List ID', 'medova' ),
                'subtitle' => esc_html__( 'Set mailchimp list id.', 'medova' ),
            ),
        ),
    ) );

    /* End Subscribe */

    // -> START Social Media

    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Social', 'medova' ),
        'id'         => 'medova_social_media',
        'icon'      => 'el el-globe',
        'desc'      => esc_html__( 'Social', 'medova' ),
        'fields'     => array(
            array(
                'id'          => 'medova_social_links',
                'type'        => 'slides',
                'title'       => esc_html__('Social Profile Links', 'medova'),
                'subtitle'    => esc_html__('Add social icon and url.', 'medova'),
                'show'        => array(
                    'title'          => true,
                    'description'    => true,
                    'progress'       => false,
                    'facts-number'   => false,
                    'facts-title1'   => false,
                    'facts-title2'   => false,
                    'facts-number-2' => false,
                    'facts-title3'   => false,
                    'facts-number-3' => false,
                    'url'            => true,
                    'project-button' => false,
                    'image_upload'   => false,
                ),
                'placeholder'   => array(
                    'icon'          => esc_html__( 'Icon (example: fa fa-facebook) ','medova'),
                    'title'         => esc_html__( 'Social Icon Class', 'medova' ),
                    'description'   => esc_html__( 'Social Icon Title', 'medova' ),
                ),
            ),
        ),
    ) );
    /* End social Media */


    // -> START Footer Media
    Redux::setSection( $opt_name , array(
       'title'            => esc_html__( 'Footer', 'medova' ),
       'id'               => 'medova_footer',
       'desc'             => esc_html__( 'medova Footer', 'medova' ),
       'customizer_width' => '400px',
       'icon'              => 'el el-photo',
   ) );

   Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Pre-built Footer / Footer Builder', 'medova' ),
        'id'         => 'medova_footer_section',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'medova_footer_builder_trigger',
                'type'     => 'button_set',
                'default'  => 'prebuilt',
                'options'  => array(
                    'footer_builder'        => esc_html__('Footer Builder','medova'),
                    'prebuilt'              => esc_html__('Pre-built Footer','medova'),
                ),
                'title'    => esc_html__( 'Footer Builder', 'medova' ),
            ),
            array(
                'id'       => 'medova_footer_builder_select',
                'type'     => 'select',
                'required' => array( 'medova_footer_builder_trigger','equals','footer_builder'),
                'data'     => 'posts',
                'args'     => array(
                    'post_type'     => 'medova_footerbuild',
                    'posts_per_page' => -1,
                ),
                'on'       => esc_html__( 'Enabled', 'medova' ),
                'off'      => esc_html__( 'Disable', 'medova' ),
                'title'    => esc_html__( 'Select Footer', 'medova' ),
                'subtitle' => esc_html__( 'First make your footer from footer custom types then select it from here.', 'medova' ),
            ),
            array(
                'id'       => 'medova_footerwidget_enable',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Widget', 'medova' ),
                'default'  => 1,
                'on'       => esc_html__( 'Enabled', 'medova' ),
                'off'      => esc_html__( 'Disable', 'medova' ),
                'required' => array( 'medova_footer_builder_trigger','equals','prebuilt'),
            ),
            array(
                'id'       => 'medova_footer_background',
                'type'     => 'background',
                'title'    => esc_html__( 'Footer Widget Background', 'medova' ),
                'subtitle' => esc_html__( 'Set footer background.', 'medova' ),
                'output'   => array( '.prebuilt-foo' ),
                'required' => array( 'medova_footerwidget_enable','=','1' ),
            ),
            array(
                'id'       => 'medova_footer_widget_title_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Widget Title Color', 'medova' ),
                'required' => array('medova_footerwidget_enable','=','1'),
                'output'   => array( '.footer-widget .widget_title' ),
            ),
            array(
                'id'       => 'medova_footer_widget_anchor_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Widget Anchor Color', 'medova' ),
                'required' => array('medova_footerwidget_enable','=','1'),
                'output'   => array( '.footer-widget a' ),
            ),
            array(
                'id'       => 'medova_footer_widget_anchor_hov_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Widget Anchor Hover Color', 'medova' ),
                'required' => array('medova_footerwidget_enable','=','1'),
                'output'   => array( '--theme-color'    =>  '.footer-widget a:hover' ),
            ),

        ),
    ) );


    // -> START Footer Bottom
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Footer Bottom', 'medova' ),
        'id'         => 'medova_footer_bottom',
        'subsection' => true,
        'fields'     => array(
            array(
                'id'       => 'medova_disable_footer_bottom',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Bottom?', 'medova' ),
                'default'  => 1,
                'on'       => esc_html__('Enabled','medova'),
                'off'      => esc_html__('Disable','medova'),
                'required' => array('medova_footer_builder_trigger','equals','prebuilt'),
            ),
            array(
                'id'       => 'medova_footer_bottom_background2',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Bottom Background Color', 'medova' ),
                'required' => array( 'medova_disable_footer_bottom','=','1' ),
                'output'   => array( 'background-color'   =>   '.prebuilt-foo .copyright-wrap' ),
            ),
            array(
                'id'       => 'medova_copyright_text',
                'type'     => 'text',
                'title'    => esc_html__( 'Copyright Text', 'medova' ),
                'subtitle' => esc_html__( 'Add Copyright Text', 'medova' ),
                'default'  => sprintf( '<i class="fal fa-copyright"></i> %s By <a href="%s">%s</a>. All Rights Reserved.',date('Y'),esc_url(esc_url( home_url('/') )),__( 'Medova','medova' ) ),
                'required' => array( 'medova_disable_footer_bottom','equals','1' ),
            ),
            array(
                'id'       => 'medova_footer_social_media',
                'type'     => 'switch',
                'title'    => esc_html__( 'Footer Bottom?', 'medova' ),
                'default'  => 1,
                'on'       => esc_html__('Enabled','medova'),
                'off'      => esc_html__('Disable','medova'),
                'required' => array('medova_footer_builder_trigger','equals','prebuilt'),
            ),
            array(
                'id'       => 'medova_footer_copyright_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Copyright Text Color', 'medova' ),
                'subtitle' => esc_html__( 'Set footer copyright text color', 'medova' ),
                'required' => array( 'medova_disable_footer_bottom','equals','1'),
                'output'    => array('--white-color' => '.prebuilt-foo .copyright-text'),
            ),
            array(
                'id'       => 'medova_footer_copyright_acolor',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Copyright Ancor Color', 'medova' ),
                'subtitle' => esc_html__( 'Set footer copyright ancor color', 'medova' ),
                'required' => array( 'medova_disable_footer_bottom','equals','1'),
                'output'    => array('color' => '.prebuilt-foo  .copyright-text a'),
            ),
            array(
                'id'       => 'medova_footer_copyright_a_hover_color',
                'type'     => 'color',
                'title'    => esc_html__( 'Footer Copyright Ancor Hover Color', 'medova' ),
                'subtitle' => esc_html__( 'Set footer copyright ancor Hover color', 'medova' ),
                'required' => array( 'medova_disable_footer_bottom','equals','1'),
                'output'    => array('color' => '.prebuilt-foo .copyright-text a:hover'),
            ), 

        )
    ));

    /* End Footer Media */

    // -> START Custom Css
    Redux::setSection( $opt_name, array(
        'title'      => esc_html__( 'Custom Css', 'medova' ),
        'id'         => 'medova_custom_css_section',
        'icon'  => 'el el-css',
        'fields'     => array(
            array(
                'id'       => 'medova_css_editor',
                'type'     => 'ace_editor',
                'title'    => esc_html__('CSS Code', 'medova'),
                'subtitle' => esc_html__('Paste your CSS code here.', 'medova'),
                'mode'     => 'css',
                'theme'    => 'monokai',
            )
        ),
    ) );

    /* End custom css */



    if ( file_exists( dirname( __FILE__ ) . '/../README.md' ) ) {
        $section = array(
            'icon'   => 'el el-list-alt',
            'title'  => __( 'Documentation', 'medova' ),
            'fields' => array(
                array(
                    'id'       => '17',
                    'type'     => 'raw',
                    'markdown' => true,
                    'content_path' => dirname( __FILE__ ) . '/../README.md', // FULL PATH, not relative please
                    //'content' => 'Raw content here',
                ),
            ),
        );
        Redux::setSection( $opt_name, $section );
    }
    /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'medova' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'medova' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }