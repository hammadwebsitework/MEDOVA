<?php

/**
 * Include and setup custom metaboxes and fields. (make sure you copy this file to outside the CMB2 directory)
 *
 * Be sure to replace all instances of 'yourprefix_' with your project's prefix.
 * http://nacin.com/2010/05/11/in-wordpress-prefix-everything/
 *
 * @category YourThemeOrPlugin
 * @package  Demo_CMB2
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/WebDevStudios/CMB2
 */

 /**
 * Only return default value if we don't have a post ID (in the 'post' query variable)
 *
 * @param  bool  $default On/Off (true/false)
 * @return mixed          Returns true or '', the blank default
 */
function medova_set_checkbox_default_for_new_post( $default ) {
	return isset( $_GET['post'] ) ? '' : ( $default ? (string) $default : '' );
}

add_action( 'cmb2_admin_init', 'medova_register_metabox' );

/**
 * Hook in and add a demo metabox. Can only happen on the 'cmb2_admin_init' or 'cmb2_init' hook.
 */

function medova_register_metabox() {

	$prefix = '_medova_';

	$prefixpage = '_medovapage_';
	
	$medova_post_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'blog_post_control',
		'title'         => esc_html__( 'Post Thumb Controller', 'medova' ),
		'object_types'  => array( 'post' ), // Post type
		'closed'        => true
	) );

    $medova_post_meta->add_field( array(
        'name' => esc_html__( 'Post Format Video', 'medova' ),
        'desc' => esc_html__( 'Use This Field When Post Format Video', 'medova' ),
        'id'   => $prefix . 'post_format_video',
        'type' => 'text_url',
    ) );

	$medova_post_meta->add_field( array(
		'name' => esc_html__( 'Post Format Audio', 'medova' ),
		'desc' => esc_html__( 'Use This Field When Post Format Audio', 'medova' ),
		'id'   => $prefix . 'post_format_audio',
        'type' => 'oembed',
    ) );
	$medova_post_meta->add_field( array(
		'name' => esc_html__( 'Post Thumbnail For Slider', 'medova' ),
		'desc' => esc_html__( 'Use This Field When You Want A Slider In Post Thumbnail', 'medova' ),
		'id'   => $prefix . 'post_format_slider',
        'type' => 'file_list',
    ) );
	
	$medova_page_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'page_meta_section',
		'title'         => esc_html__( 'Page Meta', 'medova' ),
		'object_types'  => array( 'page'), // Post type
        'closed'        => true
    ) );

    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Page Breadcrumb Area', 'medova' ),
		'desc' => esc_html__( 'check to display page breadcrumb area.', 'medova' ),
		'id'   => $prefix . 'page_breadcrumb_area',
        'type' => 'select',
        'default' => '1',
        'options'   => array(
            '1'   => esc_html__('Show','medova'),
            '2'     => esc_html__('Hide','medova'),
        )
    ) );


    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Page Breadcrumb Settings', 'medova' ),
		'id'   => $prefix . 'page_breadcrumb_settings',
        'type' => 'select',
        'default'   => 'global',
        'options'   => array(
            'global'   => esc_html__('Global Settings','medova'),
            'page'     => esc_html__('Page Settings','medova'),
        )
	) );

    $medova_page_meta->add_field( array(
        'name'    => esc_html__( 'Breadcumb Image', 'medova' ),
        'desc'    => esc_html__( 'Upload an image or enter an URL.', 'medova' ),
        'id'      => $prefix . 'breadcumb_image',
        'type'    => 'file',
        // Optional:
        'options' => array(
            'url' => false, // Hide the text input for the url
        ),
        'text'    => array(
            'add_upload_file_text' => __( 'Add File', 'medova' ) // Change upload button text. Default: "Add or Upload File"
        ),
        'preview_size' => 'large', // Image size to use when previewing in the admin.
    ) );

    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Page Title', 'medova' ),
		'desc' => esc_html__( 'check to display Page Title.', 'medova' ),
		'id'   => $prefix . 'page_title',
        'type' => 'select',
        'default' => '1',
        'options'   => array(
            '1'   => esc_html__('Show','medova'),
            '2'     => esc_html__('Hide','medova'),
        )
	) );

    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Page Title Settings', 'medova' ),
		'id'   => $prefix . 'page_title_settings',
        'type' => 'select',
        'options'   => array(
            'default'  => esc_html__('Default Title','medova'),
            'custom'  => esc_html__('Custom Title','medova'),
        ),
        'default'   => 'default'
    ) );

    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Custom Page Title', 'medova' ),
		'id'   => $prefix . 'custom_page_title',
        'type' => 'text'
    ) );

    $medova_page_meta->add_field( array(
		'name' => esc_html__( 'Breadcrumb', 'medova' ),
		'desc' => esc_html__( 'Select Show to display breadcrumb area', 'medova' ),
		'id'   => $prefix . 'page_breadcrumb_trigger',
        'type' => 'switch_btn',
        'default' => medova_set_checkbox_default_for_new_post( true ),
    ) );

    $medova_layout_meta = new_cmb2_box( array(
		'id'            => $prefixpage . 'page_layout_section',
		'title'         => esc_html__( 'Page Layout', 'medova' ),
        'context' 		=> 'side',
        'priority' 		=> 'high',
        'object_types'  => array( 'page', ), // Post type
        'closed'        => true
	) );

	$medova_layout_meta->add_field( array(
		'desc'       => esc_html__( 'Set page layout container,container fluid,fullwidth or both. It\'s work only in template builder page.', 'medova' ),
		'id'         => $prefix . 'custom_page_layout',
		'type'       => 'radio',
        'options' => array(
            '1' => esc_html__( 'Container', 'medova' ),
            '2' => esc_html__( 'Container Fluid', 'medova' ),
            '3' => esc_html__( 'Fullwidth', 'medova' ),
        ),
	) );

	// code for body class//

    $medova_layout_meta->add_field( array(
    	'name' => esc_html__( 'Insert Your Body Class', 'medova' ),
    	'id'   => $prefix . 'custom_body_class',
    	'type' => 'text'
    ) );


    $medova_extra_listing_meta = new_cmb2_box( array(
        'id'            => $prefixpage . 'listingmeta_section',
        'title'         => esc_html__( 'Additional Informations', 'medova' ),
        'object_types'  => array( 'at_biz_dir' ), // Post type
        'closed'        => true,
        'context'       => 'side',
        'priority'      => 'default'
    ) );

    $medova_extra_listing_meta->add_field( array(
        'name' => esc_html__( 'Address', 'medova' ),
        'id'   => $prefix . 'medova_address',
        'type' => 'text'
    ) );
    $medova_extra_listing_meta->add_field( array(
        'name' => esc_html__( 'Short Description', 'medova' ),
        'id'   => $prefix . 'medova_short_description',
        'type' => 'textarea'
    ) );
    $medova_extra_listing_meta->add_field( array(
        'name' => esc_html__( 'Bad Room', 'medova' ),
        'id'   => $prefix . 'medova_bed_count',
        'type' => 'text'
    ) );
    $medova_extra_listing_meta->add_field( array(
        'name' => esc_html__( 'Bath Room', 'medova' ),
        'id'   => $prefix . 'medova_bath_count',
        'type' => 'text'
    ) );
    $medova_extra_listing_meta->add_field( array(
        'name' => esc_html__( 'Room Size', 'medova' ),
        'id'   => $prefix . 'medova_room_size',
        'type' => 'text'
    ) );

}

add_action( 'cmb2_admin_init', 'medova_register_taxonomy_metabox' );
/**
 * Hook in and add a metabox to add fields to taxonomy terms
 */
function medova_register_taxonomy_metabox() {

    $prefix = '_medova_';
	/**
	 * Metabox to add fields to categories and tags
	 */
	$medova_term_meta = new_cmb2_box( array(
		'id'               => $prefix.'term_edit',
		'title'            => esc_html__( 'Category Metabox', 'medova' ),
		'object_types'     => array( 'term' ),
		'taxonomies'       => array( 'category'),
	) );
	$medova_term_meta->add_field( array(
		'name'     => esc_html__( 'Extra Info', 'medova' ),
		'id'       => $prefix.'term_extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );
	$medova_term_meta->add_field( array(
		'name' => esc_html__( 'Category Image', 'medova' ),
		'desc' => esc_html__( 'Set Category Image', 'medova' ),
		'id'   => $prefix.'term_avatar',
        'type' => 'file',
        'text'    => array(
			'add_upload_file_text' => esc_html__('Add Image','medova') // Change upload button text. Default: "Add or Upload File"
		),
	) );


	/**
	 * Metabox for the user profile screen
	 */
	$medova_user = new_cmb2_box( array(
		'id'               => $prefix.'user_edit',
		'title'            => esc_html__( 'User Profile Metabox', 'medova' ), // Doesn't output for user boxes
		'object_types'     => array( 'user' ), // Tells CMB2 to use user_meta as post_meta
		'show_names'       => true,
		'new_user_section' => 'add-new-user', // where form will show on new user page. 'add-existing-user' is only other valid option.
	) );
    $medova_user->add_field( array(
		'name' => esc_html__( 'Author Designation', 'medova' ),
		'desc' => esc_html__( 'Use This Field When Author Designation', 'medova' ),
		'id'   => $prefix . 'author_desig',
        'type' => 'text',
    ) );
	$medova_user->add_field( array(
		'name'     => esc_html__( 'Social Profile', 'medova' ),
		'id'       => $prefix.'user_extra_info',
		'type'     => 'title',
		'on_front' => false,
	) );

	$group_field_id = $medova_user->add_field( array(
        'id'          => $prefix .'social_profile_group',
        'type'        => 'group',
        'description' => __( 'Social Profile', 'medova' ),
        'options'     => array(
            'group_title'       => __( 'Social Profile {#}', 'medova' ), // since version 1.1.4, {#} gets replaced by row number
            'add_button'        => __( 'Add Another Social Profile', 'medova' ),
            'remove_button'     => __( 'Remove Social Profile', 'medova' ),
            'closed'         => true
        ),
    ) );

    $medova_user->add_group_field( $group_field_id, array(
        'name'        => __( 'Icon Class', 'medova' ),
        'id'          => $prefix .'social_profile_icon',
        'type'        => 'text', // This field type
    ) );

    $medova_user->add_group_field( $group_field_id, array(
        'desc'       => esc_html__( 'Set social profile link.', 'medova' ),
        'id'         => $prefix . 'lawyer_social_profile_link',
        'name'       => esc_html__( 'Social Profile link', 'medova' ),
        'type'       => 'text'
    ) );
}
