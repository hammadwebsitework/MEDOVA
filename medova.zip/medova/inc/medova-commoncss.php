<?php
// Block direct access
if( !defined( 'ABSPATH' ) ){
    exit();
}
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// enqueue css
function medova_common_custom_css(){
	wp_enqueue_style( 'medova-color-schemes', get_template_directory_uri().'/assets/css/color.schemes.css' );

    $CustomCssOpt  = medova_opt( 'medova_css_editor' );
	if( $CustomCssOpt ){
		$CustomCssOpt = $CustomCssOpt;
	}else{
		$CustomCssOpt = '';
	}

    $customcss = "";
    
    if( get_header_image() ){
        $medova_header_bg =  get_header_image();
    }else{
        if( medova_meta( 'page_breadcrumb_settings' ) == 'page' ){
            if( ! empty( medova_meta( 'breadcumb_image' ) ) ){
                $medova_header_bg = medova_meta( 'breadcumb_image' );
            }
        }
    }
    
    if( !empty( $medova_header_bg ) ){
        $customcss .= ".breadcumb-wrapper{
            background-image:url('{$medova_header_bg}')!important;
        }";
    }
    
	// Theme color
	$medovathemecolor = medova_opt('medova_theme_color'); 
    if( !empty( $medovathemecolor ) ){
        list($r, $g, $b) = sscanf( $medovathemecolor, "#%02x%02x%02x");

        $medova_real_color = $r.','.$g.','.$b;
        if( !empty( $medovathemecolor ) ) {
            $customcss .= ":root {
            --theme-color: rgb({$medova_real_color});
            }";
        }
    }
    // Heading  color
	$medovaheadingcolor = medova_opt('medova_heading_color');
    if( !empty( $medovaheadingcolor ) ){
        list($r, $g, $b) = sscanf( $medovaheadingcolor, "#%02x%02x%02x");

        $medova_real_color = $r.','.$g.','.$b;
        if( !empty( $medovaheadingcolor ) ) {
            $customcss .= ":root {
                --title-color: rgb({$medova_real_color});
            }";
        }
    }
    // Body color
	$medovabodycolor = medova_opt('medova_body_color');
    if( !empty( $medovabodycolor ) ){
        list($r, $g, $b) = sscanf( $medovabodycolor, "#%02x%02x%02x");

        $medova_real_color = $r.','.$g.','.$b;
        if( !empty( $medovabodycolor ) ) {
            $customcss .= ":root {
                --body-color: rgb({$medova_real_color});
            }";
        }
    }

     // Body font
     $medovabodyfont = medova_opt('medova_theme_body_font', 'font-family');
     if( !empty( $medovabodyfont ) ) {
         $customcss .= ":root {
             --body-font: $medovabodyfont ;
         }";
     }
 
     // Heading font
     $medovaheadingfont = medova_opt('medova_theme_heading_font', 'font-family');
     if( !empty( $medovaheadingfont ) ) {
         $customcss .= ":root {
             --title-font: $medovaheadingfont ;
         }";
     }


    if(medova_opt('medova_menu_icon_class')){
        $menu_icon_class = medova_opt( 'medova_menu_icon_class' );
    }else{
        $menu_icon_class = 'e00d';
    }

    if( !empty( $menu_icon_class ) ) {
        $customcss .= ":root {
            .main-menu ul.sub-menu li a:before {
                content: \"\\$menu_icon_class\";
            }
        }";
    }

	if( !empty( $CustomCssOpt ) ){
		$customcss .= $CustomCssOpt;
	}

    wp_add_inline_style( 'medova-color-schemes', $customcss );
}
add_action( 'wp_enqueue_scripts', 'medova_common_custom_css', 100 );