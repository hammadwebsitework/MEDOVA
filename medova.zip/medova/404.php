<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

    // Block direct access
    if( !defined( 'ABSPATH' ) ){
        exit();
    }

    if( class_exists( 'ReduxFramework' ) ) {
        $medova404title     = medova_opt( 'medova_error_title' );
        $medova404subtitle     = medova_opt( 'medova_error_subtitle' );
        $medova404btntext      = medova_opt( 'medova_error_btn_text' );
    } else {
        $medova404title     = __( 'Error 404', 'medova' );
        $medova404subtitle     = __( 'Oops! The page you’re looking for doesn’t exist', 'medova' );
        $medova404btntext      = __( 'Go Back Home', 'medova');

    }

    // get header //
    get_header(); 

    echo '<section class="space">';
        echo '<div class="container">';
            echo '<div class="row justify-content-center align-items-center">';
                echo '<div class="col-lg-5">';
                    echo '<div class="error-content">';
                        echo '<h2 class="error-title">'.esc_html( $medova404title ).'</h2>';
                        echo '<p class="error-text">'.esc_html( $medova404subtitle ).'</p>';
                        echo '<a href="'.esc_url( home_url('/') ).'" class="th-btn th-black"><i class="fal fa-home me-2"></i>'.esc_html( $medova404btntext ).'</a>';
                    echo '</div>';
                echo '</div>';
                echo '<div class="col-lg-7">';
                    echo '<div class="error-img">';
                        if(!empty(medova_opt('medova_error_img', 'url' ) )){
                            echo '<img src="'.esc_url( medova_opt('medova_error_img', 'url' ) ).'" alt="'.esc_attr__('404 image', 'medova').'">';
                        }else{
                            echo '<img src="'.get_template_directory_uri().'/assets/img/theme-img/error.svg" alt="'.esc_attr__('404 image', 'medova').'">';
                        }
                    echo '</div>';
                echo '</div>';
            echo '</div>';
        echo '</div>';
    echo '</section>';
    //footer
    get_footer();