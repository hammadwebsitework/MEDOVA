<?php
/**
 * @Packge     : Medova
 * @Version    : 1.0
 * @Author     : Themeholy
 * @Author URI : https://themeforest.net/user/themeholy
 *
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Include File
 *
 */

$selected_options   =   get_option('et_selected_medova_demo_plugin');

// Constants
require_once get_parent_theme_file_path() . '/inc/medova-constants.php';

//theme setup
require_once MEDOVA_DIR_PATH_INC . 'theme-setup.php';

//essential scripts
require_once MEDOVA_DIR_PATH_INC . 'essential-scripts.php';


// Woo Hooks
require_once MEDOVA_DIR_PATH_INC . 'woo-hooks/medova-woo-hooks.php';

// Woo Hooks Functions
require_once MEDOVA_DIR_PATH_INC . 'woo-hooks/medova-woo-hooks-functions.php';


// plugin activation
require_once MEDOVA_DIR_PATH_FRAM . 'plugins-activation/medova-active-plugins.php';

// theme dynamic css
require_once MEDOVA_DIR_PATH_INC . 'medova-commoncss.php';

// meta options
require_once MEDOVA_DIR_PATH_FRAM . 'medova-meta/medova-config.php';

// page breadcrumbs
require_once MEDOVA_DIR_PATH_INC . 'medova-breadcrumbs.php';

// sidebar register
require_once MEDOVA_DIR_PATH_INC . 'medova-widgets-reg.php';

//essential functions
require_once MEDOVA_DIR_PATH_INC . 'medova-functions.php';

// helper function
require_once MEDOVA_DIR_PATH_INC . 'wp-html-helper.php';

// Demo Data
require_once MEDOVA_DEMO_DIR_PATH . 'demo-import.php';

// pagination
require_once MEDOVA_DIR_PATH_INC . 'wp_bootstrap_pagination.php';



// hooks
require_once MEDOVA_DIR_PATH_HOOKS . 'hooks.php';

// hooks funtion
require_once MEDOVA_DIR_PATH_HOOKS . 'hooks-functions.php'; 







// add_action('wp_ajax_update_cart_count', 'update_cart_count');
// add_action('wp_ajax_nopriv_update_cart_count', 'update_cart_count');





// function update_cart_count() {
//     if (class_exists('woocommerce')) {
//         global $woocommerce;
//         $product_id = intval($_POST['product_id']);
//         $woocommerce->cart->add_to_cart($product_id); // Add the product to the cart

//         $cart_count = $woocommerce->cart->cart_contents_count;
//         echo esc_html($cart_count);
//     }
//     wp_die();
// }

function medova_register_block_patterns() {
    register_block_pattern(
        'medova/hero-section',
        array(
            'title'       => __( 'Hero Section', 'medova' ),
            'description' => _x( 'A custom hero section with image and text', 'Block pattern description', 'medova' ),
            'content'     => '<!-- wp:paragraph --><p>Your content here...</p><!-- /wp:paragraph -->',
        )
    );
}
add_action( 'init', 'medova_register_block_patterns' );

add_filter( 'woocommerce_add_to_cart_fragments', 'update_cart_count_fragment' );

function update_cart_count_fragment( $fragments ) {
    ob_start();
    ?>
    <span class="my-cart-count">
        <?php echo WC()->cart->get_cart_contents_count(); ?>
    </span>
    <?php
    $fragments['.my-cart-count'] = ob_get_clean();
    return $fragments;
}
