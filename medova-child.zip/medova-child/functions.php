<?php
/**
 *
 * @Packge      Medova 
 * @Author      Themeholy
 * @Author URL  https://themeforest.net/user/themeholy 
 * @version     1.0
 *
 */

/**
 * Enqueue style of child theme
 */
function medova_child_enqueue_styles() {

    wp_enqueue_style( 'medova-style', get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'medova-child-style', get_stylesheet_directory_uri() . '/style.css',array( 'medova-style' ),wp_get_theme()->get('Version'));
}
add_action( 'wp_enqueue_scripts', 'medova_child_enqueue_styles', 100000 );

if( !function_exists('medova_loop_product_thumbnail') ) {
    function medova_loop_product_thumbnail( ) {
        global $product;
        $count = $product->get_review_count();
        $product_categories = get_the_terms( get_the_ID(), 'product_cat' );
        $first_category_name = $product_categories[0]->name;
        $first_category_url = get_term_link( $product_categories[0] );

        if($count == 1){
            $review = 'Review';
        }else{
            $review = 'Reviews';
        }

        echo '<div class="th-product th-product-box">';
            echo '<div class="product-img">';
            if( has_post_thumbnail() ){
                    the_post_thumbnail( 'medova-shop-small-image' );
                echo '<div class="actions">';
                    // Quick View Button
                    if( class_exists( 'WPCleverWoosq' ) ){
                        echo do_shortcode('[woosq]');
                    }
                    // Cart Button
                    woocommerce_template_loop_add_to_cart_action_button();
                    // Wishlist Button
                    if (class_exists('WPCleverWoosw')) {
                        echo do_shortcode('[woosw]');
                    }
                    
                echo '</div>';
                if( $product->is_type('simple') || $product->is_type('external') || $product->is_type('grouped') ) {

                    $regular_price  = get_post_meta( $product->get_id(), '_regular_price', true ); 
                    $sale_price     = get_post_meta( $product->get_id(), '_sale_price', true );
                    if( !empty($sale_price) ) {
                        if( $regular_price > $sale_price ){
                            echo '<span class="product-tag">'.esc_html__('Sale', 'medova').'</span>';
                        }
                    }
                }
            }
            echo '</div>';
            echo '<div class="product-content">'; 
                echo '<h3 class="product-title"><a href="'.esc_url( get_permalink() ).'">'.esc_html( get_the_title() ).'</a></h3>';
                echo woocommerce_template_loop_price();
                
                echo '<div class="btn-group justify-content-between">';


                    if( ! empty( $product->get_sku() ) ){
                        echo '<span class="sku_wrapper">'.esc_html__( 'SKU: ', 'medova' ).'<span class="sku">'.$product->get_sku().'</span></span>';
                    }

                    woocommerce_template_loop_add_to_cart();

                echo '</div>';


            echo '</div>';
        echo '</div>';
    }
}


add_filter( 'woocommerce_cart_item_removed_notice_type', '__return_false' );










// Replace "Shopping Cart" with "Cart" in Medova mini cart
add_filter('gettext', 'medova_force_mini_cart_title', 20, 3);
function medova_force_mini_cart_title($translated_text, $text, $domain){
    if($text === 'Shopping cart' && $domain === 'medova'){
        $translated_text = 'Your Cart';
    }
    return $translated_text;
}

// Show archive description above products if the theme forgot to call it
add_action('woocommerce_before_shop_loop', function () {
    if ( is_shop() || is_product_taxonomy() ) {
        do_action('woocommerce_archive_description');
    }
}, 5);





/**
 * Quote-style WooCommerce setup (child theme)
 * - No payment required
 * - Keep checkout submit visible ("Send Request")
 * - Add "Proceed to Send" button on Cart
 * - Remove price/total columns & cart totals
 * - Rename cart buttons
 */

/* ---------- A) CART: hide price & total, remove totals, rename buttons, add CTA ---------- */

/* Hide unit price & line subtotal values server-side */
add_filter( 'woocommerce_cart_item_price', '__return_empty_string' );
add_filter( 'woocommerce_cart_item_subtotal', '__return_empty_string' );

/* Remove the cart totals & cross-sells block (this also removes default proceed button there) */
add_action( 'template_redirect', function () {
    remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cart_totals', 10 );
    remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
});

/* Rename cart page buttons */
add_filter( 'gettext', function( $translated, $text, $domain ) {
    if ( in_array( $domain, array( 'woocommerce', 'medova' ), true ) ) {
        if ( $text === 'Update cart' )         return __( 'Save Cart', 'medova' );
        if ( $text === 'Continue Shopping' )   return __( 'Add More Products', 'medova' );
        if ( $text === 'Proceed to checkout' ) return __( 'Proceed to Send', 'medova' );
    }
    return $translated;
}, 10, 3 );

/* Add our own "Proceed to Send" button below the cart table */
add_action( 'woocommerce_after_cart_table', function () {
    if ( WC()->cart && ! WC()->cart->is_empty() ) {
        $target_url = wc_get_checkout_url(); // change to your custom quote page if needed
        echo '<div class="rq-cart-cta" style="margin-top:16px; display:flex; justify-content:flex-end;">';
        echo '<a class="button alt th-btn proceed-to-send" href="' . esc_url( $target_url ) . '">'
             . esc_html__( 'Proceed to Send', 'medova' ) . '</a>';
        echo '</div>';
    }
});

/* CSS fallback to hide hardcoded price/total columns in the table markup */
add_action( 'wp_head', function () {
    if ( ! is_cart() ) return;
    echo '<style>
      .cart-col-price, .cart-col-total { display:none !important; }
      td.product-price, td.product-subtotal { display:none !important; }
    </style>';
});

/* JS to remove Price/Total columns entirely and fix colspan (theme-specific headers) */
add_action( 'wp_footer', function () {
    if ( ! is_cart() ) return; ?>
    <script>
    (function(){
      var table = document.querySelector('.woocommerce-cart-form__contents');
      if (!table) return;
      var thead = table.querySelector('thead');
      var headRow = thead ? thead.querySelector('tr') : null;
      if (!headRow) return;

      function isPriceOrTotal(th){
        var cls = th.className || '';
        var txt = (th.textContent || '').trim().toLowerCase();
        return cls.indexOf('cart-col-price')>-1 || cls.indexOf('cart-col-total')>-1 ||
               txt==='price' || txt==='price/unit' || txt==='total';
      }

      var idx = [];
      Array.prototype.slice.call(headRow.children).forEach(function(th,i){
        if (isPriceOrTotal(th)) idx.push(i);
      });
      if (!idx.length) return;
      idx.sort(function(a,b){return b-a;});
      idx.forEach(function(i){ headRow.deleteCell(i); });

      table.querySelectorAll('tbody tr').forEach(function(row){
        var cells = row.children;
        if (!cells || !cells.length) return;
        idx.forEach(function(i){ if (cells[i]) row.deleteCell(i); });
        var actions = row.querySelector('td.actions');
        if (actions) actions.colSpan = row.children.length;
      });
    })();
    </script>
<?php
});

/* ---------- B) CHECKOUT: no payment required + ensure submit button shows ---------- */

/* Tell WooCommerce no payment is needed (even if totals > 0, you’re collecting a quote) */
add_filter( 'woocommerce_cart_needs_payment', function( $needs_payment, $cart ) {
    return false;
}, 10, 2 );

/* Friendly message instead of "no available payment methods" */
add_filter( 'woocommerce_no_available_payment_methods_message', function( $msg ) {
    return __( 'No payment is required. Review your details and click “Send Request”.', 'medova' );
}, 10 );
add_filter( 'woocommerce_no_available_payment_methods_message_no_registration', function( $msg ) {
    return __( 'No payment is required. Review your details and click “Send Request”.', 'medova' );
}, 10 );

/* Use "Send Request" for the final submit */
add_filter( 'woocommerce_order_button_text', function( $text ) {
    return __( 'Send Request', 'medova' );
});

/**
 * IMPORTANT: Keep #payment visible (so the default submit button can render),
 * but hide ONLY the payment method list if present.
 * If you previously hid #payment entirely, remove that code.
 */
add_action( 'wp_head', function () {
    if ( ! is_checkout() ) return;
    echo '<style>
      .woocommerce-checkout .wc_payment_methods, 
      .woocommerce-checkout .payment_methods,
      .woocommerce-checkout .wc_payment_method { display:none !important; }
      /* keep #payment visible so the submit area can appear */
    </style>';
});

/**
 * Fallback: if some theme still doesn’t output a submit button when no gateways,
 * render our own submit button above the payment area.
 */
add_action( 'woocommerce_review_order_before_payment', function () {
    echo '<div class="rq-checkout-cta" style="margin:12px 0; text-align:right;">';
    echo '<button type="submit" class="button alt th-btn" name="woocommerce_checkout_place_order" id="place_order" value="'
         . esc_attr__( 'Send Request', 'medova' ) . '">'
         . esc_html__( 'Send Request', 'medova' ) . '</button>';
    echo '</div>';
}, 5 );




// Checkout: hide the fallback button block if it exists (keep only the main right-side submit)
add_action('wp_head', function () {
    if ( ! is_checkout() ) return;
    echo '<style>.rq-checkout-cta{display:none!important;}</style>';
});






/**
 * Checkout: strip Price & Total columns from order review (theme-agnostic)
 */
add_action('wp_head', function () {
    if ( ! is_checkout() ) return;
    echo '<style>
      /* Hide any totals box/footer the theme might render */
      .woocommerce-checkout-review-order-table tfoot{display:none!important;}
    </style>';
});

add_action('wp_footer', function () {
    if ( ! is_checkout() ) return; ?>
    <script>
    (function(){
      // Remove "Price" & "Total" columns by matching header text, then delete same indices in all rows
      function stripPriceTotalCols(){
        var table = document.querySelector('.woocommerce-checkout-review-order-table');
        if(!table) return;

        // Get header row
        var headRow = table.tHead ? table.tHead.rows[0] : (table.querySelector('thead tr') || null);
        if(!headRow) return;

        // Collect column indices to remove (match header text or theme classes)
        var removeIdx = [];
        Array.from(headRow.cells).forEach(function(th, i){
          var txt = (th.textContent || '').trim().toLowerCase();
          var cls = th.className || '';
          if (
            txt === 'price' ||
            txt === 'total' ||
            txt === 'subtotal' ||              // some themes label header "Subtotal"
            /product-(?:price|total)/.test(cls) // fallback by class
          ){
            removeIdx.push(i);
          }
        });

        // If nothing matched, nothing to do
        if(!removeIdx.length) return;

        // Deduplicate and remove from highest index to lowest to avoid shifting
        removeIdx = Array.from(new Set(removeIdx)).sort(function(a,b){return b-a;});

        // Helper to strip cells at indices for all rows in a section
        function stripSection(sec){
          if(!sec) return;
          Array.from(sec.rows).forEach(function(row){
            removeIdx.forEach(function(idx){
              if(row.cells[idx]) row.deleteCell(idx);
            });
            // If a row has a single "message" cell with colspan, expand it to current column count
            Array.from(row.cells).forEach(function(td){
              if (td.colSpan && td.colSpan > 1) td.colSpan = row.cells.length;
            });
          });
        }

        stripSection(table.tHead || table.querySelector('thead'));
        stripSection(table.tBodies[0] || table.querySelector('tbody'));

        // Remove footer entirely (totals/shipping/etc) for quote flow
        var tf = table.tFoot || table.querySelector('tfoot');
        if (tf) tf.parentNode.removeChild(tf);
      }

      // Run now…
      document.addEventListener('DOMContentLoaded', stripPriceTotalCols);
      stripPriceTotalCols();

      // …and every time WooCommerce updates the checkout fragment
      if (window.jQuery) {
        jQuery(document.body).on('updated_checkout', stripPriceTotalCols);
      } else {
        // Fallback: watch for table changes
        var cnt = document.querySelector('.woocommerce-checkout-review-order');
        if (cnt) {
          new MutationObserver(function(){ stripPriceTotalCols(); })
            .observe(cnt, {childList:true, subtree:true});
        }
      }
    })();
    </script>
<?php
});





/**
 * WooCommerce Inquiry Customizations
 * - Change "Your Order" to "Your Inquiry"
 * - Change "Order Notes" to "Your Inquiry Notes"
 * - Remove extra description under notes
 */

/* 1) Change "Your order" heading above order review table */
add_filter('woocommerce_order_review_heading', function () {
    return __('Your Inquiry', 'medova');
});

/* 2) Fallback: if the theme outputs "Your Order" via gettext */
add_filter('gettext', function ($translated, $text, $domain) {
    if (trim($text) === 'Your order' || trim($text) === 'Your Order') {
        return __('Your Inquiry', 'medova');
    }
    return $translated;
}, 10, 3);

/* 3) Last-resort: change it via DOM if the theme hardcodes markup */
add_action('wp_footer', function () {
    if (!is_checkout()) return; ?>
    <script>
    (function(){
      var h = document.querySelector(
        '.woocommerce-checkout-review-order h3, ' +
        '.woocommerce-order-review h3, ' +
        '.woocommerce-checkout-review-order .wc-block-components-title, ' +
        '.woocommerce-checkout-review-order .title'
      );
      if (h && /your order/i.test(h.textContent.trim())) {
        h.textContent = 'Your Inquiry';
      }
    })();
    </script>
<?php
});

/* 4) Change "Order notes" → "Your Inquiry Notes" */
add_filter('woocommerce_checkout_fields', function ($fields) {
    if (isset($fields['order']['order_comments'])) {
        $fields['order']['order_comments']['label']       = __('Your Inquiry Notes', 'medova');
        $fields['order']['order_comments']['placeholder'] = __('Add your inquiry notes here…', 'medova');
        $fields['order']['order_comments']['description'] = ''; // remove duplicate line
    }
    return $fields;
});



/* 5) Change "Billing details" → "Client Details" */
add_filter('gettext', function ($translated, $text, $domain) {
    if (trim($text) === 'Billing details' || trim($text) === 'Billing Details') {
        return __('Client Details', 'medova');
    }
    return $translated;
}, 10, 3);

/* Fallback DOM patch if theme hardcodes heading */
add_action('wp_footer', function () {
    if (!is_checkout()) return; ?>
    <script>
    (function(){
      var h = document.querySelector(
        '.woocommerce-billing-fields h3, ' +
        '.woocommerce-billing-fields .title, ' +
        '.woocommerce-billing-fields fieldset legend'
      );
      if (h && /billing details/i.test(h.textContent.trim())) {
        h.textContent = 'Client Details';
      }
    })();
    </script>
<?php
});






/**
 * Inquiry-style "Order received" (Thank You) page — functions.php only
 * - Rename headings/text
 * - Hide all prices/totals & payment method
 * - Keep simple item list + client details
 * - Add a friendly confirmation + CTA
 */

/* 1) Change the big heading on the thank-you page */
add_filter('woocommerce_thankyou_order_received_text', function ($text, $order) {
    return __('Inquiry Received', 'medova');
}, 10, 2);

/* 2) Hide line totals for each item in the order details table */
add_filter('woocommerce_order_formatted_line_subtotal', function ($subtotal, $item, $order) {
    return ''; // remove the per-line price/total column content
}, 10, 3);

/* 3) Remove the totals box rows (subtotal, shipping, method, order total, tax, discounts, etc.) */
add_filter('woocommerce_get_order_item_totals', function ($totals, $order, $tax_display) {
    // Unset any rows you don’t want in the summary box
    foreach ([
        'cart_subtotal', 'discount', 'shipping', 'shipping_method', 'payment_method',
        'fee', 'tax', 'order_total', 'subtotal'
    ] as $key) {
        if (isset($totals[$key])) unset($totals[$key]);
    }
    // Return empty array to hide the box entirely if you prefer:
    // return [];
    return $totals;
}, 10, 3);

/* 4) Rename some common labels that themes print */
add_filter('gettext', function ($translated, $text, $domain) {
    $t = trim($text);
    if ($t === 'Order details' || $t === 'Order Details') { return __('Inquiry Details', 'medova'); }
    if ($t === 'Billing address' || $t === 'Billing Address') { return __('Client Details', 'medova'); }
    if ($t === 'Shipping address' || $t === 'Shipping Address') { return __('Delivery Details', 'medova'); }
    return $translated;
}, 10, 3);

/* 5) Add a friendly message + a "Back to Products" CTA on the thank-you page */
add_action('woocommerce_thankyou', function ($order_id) {
    if (! $order_id) return;
    $shop_url = get_permalink( wc_get_page_id('shop') );
    echo '<div class="rq-thankyou-msg" style="margin:16px 0 0; padding:16px; background:#f7f7f9; border-radius:8px;">
            <p style="margin:0 0 8px; font-weight:600;">' . esc_html__('Thank you! We’ve received your inquiry.', 'medova') . '</p>
            <p style="margin:0 0 12px;">' . esc_html__('Our team will review your request and get back to you shortly.', 'medova') . '</p>
            <div style="text-align:right;">
              <a class="button th-btn" href="' . esc_url($shop_url) . '">' . esc_html__('Back to Products', 'medova') . '</a>
            </div>
          </div>';
}, 20);

/* 6) CSS hard-hiding for themes that still render price/total columns/footers */
add_action('wp_head', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return;
    echo '<style>
      /* Remove price/total columns in the items table */
      .woocommerce-order .woocommerce-table--order-details th.product-total,
      .woocommerce-order .woocommerce-table--order-details td.product-total { display:none !important; }
      /* Remove the summary (tfoot) entirely */
      .woocommerce-order .woocommerce-table--order-details tfoot { display:none !important; }
      /* Tidy the customer details block spacing */
      .woocommerce-customer-details { margin-top: 16px; }
    </style>';
});





/**
 * Inquiry flow: nuke totals on the "Order received" (thank you) page
 * - Works even with theme overrides
 */

/* 1) Prefer to empty WooCommerce-provided totals array (when respected) */
add_filter('woocommerce_get_order_item_totals', function ($totals, $order, $tax_display) {
    return []; // remove the summary box contents
}, 20, 3);

/* 2) CSS hard-hiding for common thank-you/overview & order details table totals */
add_action('wp_head', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return;
    echo '<style>
      /* Hide the top overview list that shows Total/Payment/etc. */
      .woocommerce-order-overview,
      .woocommerce-order-overview__total,
      .woocommerce-order-overview li.order-total { display:none !important; }

      /* Hide totals columns in the items table */
      .woocommerce-order .woocommerce-table--order-details th.product-total,
      .woocommerce-order .woocommerce-table--order-details td.product-total,
      .woocommerce-order .shop_table.order_details th.product-total,
      .woocommerce-order .shop_table.order_details td.product-total { display:none !important; }

      /* Hide any footer rows (subtotal, shipping, taxes, fees, discounts, total) */
      .woocommerce-order .woocommerce-table--order-details tfoot,
      .woocommerce-order .shop_table.order_details tfoot { display:none !important; }

      /* Safety: many themes add rows with these classes */
      .woocommerce-order .shop_table tfoot .cart-subtotal,
      .woocommerce-order .shop_table tfoot .order-total,
      .woocommerce-order .shop_table tfoot .shipping,
      .woocommerce-order .shop_table tfoot .tax-total,
      .woocommerce-order .shop_table tfoot .fee,
      .woocommerce-order .shop_table tfoot .discount { display:none !important; }
    </style>';
});

/* 3) DOM cleanup for stubborn themes: remove totals by header text and rows in tfoot */
add_action('wp_footer', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return; ?>
    <script>
    (function(){
      function stripTotals(){
        // Top "Order details" overview list (order number/date/total/payment)
        var overview = document.querySelector('.woocommerce-order-overview');
        if (overview) {
          // remove whole list to be safe in inquiry flow
          overview.parentNode.removeChild(overview);
        }

        // Target order-details tables
        var tables = document.querySelectorAll('.woocommerce-table--order-details, .shop_table.order_details');
        tables.forEach(function(table){
          // Remove totals header column if present
          var head = table.tHead || table.querySelector('thead');
          if (head && head.rows[0]) {
            // collect indexes for headers that look like totals/prices
            var removeIdx = [];
            Array.from(head.rows[0].cells).forEach(function(th, i){
              var txt = (th.textContent || '').trim().toLowerCase();
              var cls = th.className || '';
              if (txt === 'total' || txt === 'price' || /product-total|product-price/i.test(cls)) {
                removeIdx.push(i);
              }
            });
            removeIdx.sort(function(a,b){return b-a;});
            removeIdx.forEach(function(i){ if (head.rows[0].cells[i]) head.rows[0].deleteCell(i); });

            // Remove those same columns in tbody
            var body = table.tBodies && table.tBodies[0] ? table.tBodies[0] : table.querySelector('tbody');
            if (body) {
              Array.from(body.rows).forEach(function(row){
                removeIdx.forEach(function(i){ if (row.cells[i]) row.deleteCell(i); });
              });
            }
          }

          // Remove any footer entirely (subtotal, shipping, taxes, total)
          var foot = table.tFoot || table.querySelector('tfoot');
          if (foot && foot.parentNode) foot.parentNode.removeChild(foot);

          // Extra: remove rows by first-cell text match (in case totals appear in tbody)
          var rx = /(subtotal|total|shipping|tax|fee|discount)/i;
          var tb = table.tBodies && table.tBodies[0] ? table.tBodies[0] : table.querySelector('tbody');
          if (tb) {
            Array.from(tb.rows).forEach(function(row){
              var first = row.cells[0] ? (row.cells[0].textContent || '') : '';
              if (rx.test(first.trim())) row.parentNode.removeChild(row);
            });
          }
        });
      }

      // Run now and after any dynamic updates (rare on thank-you, but safe)
      document.addEventListener('DOMContentLoaded', stripTotals);
      stripTotals();
      if (window.jQuery) jQuery(document.body).on('wc_order_details_refreshed', stripTotals);
    })();
    </script>
<?php
});












// Thank You page CTAs (unchanged)
add_action('woocommerce_thankyou', function ($order_id) {
    if ( ! $order_id ) return;
    echo '<div class="rq-thankyou-ctas" style="margin-top:16px; display:flex; gap:12px; justify-content:flex-end; flex-wrap:wrap;">
            <button type="button" class="button th-btn rq-download-quote" data-order-id="' . esc_attr($order_id) . '">' . esc_html__('Download PDF Quote', 'medova') . '</button>
            <a class="button th-btn rq-return-home" href="' . esc_url( home_url('/') ) . '">' . esc_html__('Return to Home', 'medova') . '</a>
          </div>';
}, 30);

// Print-only "Inquiry details" (no header/footer, just the bottom details)
add_action('wp_footer', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return; ?>
    <script>
    (function(){
      function openInquiryOnly(){
        // Grab ONLY the inquiry table & (optionally) client details
        var table = document.querySelector('.woocommerce-table--order-details, .shop_table.order_details');
        var client = document.querySelector('.woocommerce-customer-details'); // optional
        if (!table) return;

        var w = window.open('', 'quote_print', 'width=900,height=900');
        if (!w) return;

        // Minimal styles: just enough to keep table readable; hide everything else
        var styles = `
          <style>
            @page { margin: 12mm; } /* printer margins; user can change */
            html, body { margin:0; padding:0; }
            body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; }
            table { width:100%; border-collapse:collapse; }
            th, td { border:1px solid #e5e5e5; padding:10px; vertical-align:top; }
            th { background:#f8f8f8; text-align:left; }
            /* kill totals/footer rows if any still present */
            tfoot { display:none !important; }
            .product-total, th.product-total { display:none !important; }
            /* remove any theme overview bits if accidentally copied */
            .woocommerce-order-overview { display:none !important; }
          </style>
        `;

        w.document.open();
        w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Inquiry Details</title>'+styles+'</head><body>');

        // Write ONLY the table and client block (no header, no CTA, no footer)
        w.document.write('<div class="inquiry-print">');
        w.document.write(table.outerHTML);
        if (client) {
          w.document.write('<div style="margin-top:16px;">' + client.innerHTML + '</div>');
        }
        w.document.write('</div>');

        w.document.write('</body></html>');
        w.document.close();

        w.focus();
        setTimeout(function(){ try { w.print(); } catch(e) {} }, 300);
      }

      document.addEventListener('click', function(e){
        var btn = e.target.closest('.rq-download-quote');
        if (!btn) return;
        e.preventDefault();
        openInquiryOnly();
      }, false);
    })();
    </script>
<?php
});






















add_action('wp_footer', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return; ?>
    <script>
    (function(){
      function openInquiryStyled(){
        var table  = document.querySelector('.woocommerce-table--order-details, .shop_table.order_details');
        var client = document.querySelector('.woocommerce-customer-details');
        if (!table) return;

        var w = window.open('', 'quote_print', 'width=900,height=900');
        if (!w) return;

        var styles = `
          <style>
            @page { margin: 15mm; }
            body {
              font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              font-size: 14px;
              line-height: 1.5;
              color: #333;
              margin: 0;
              padding: 20px;
              background: #fff;
            }
            h1 {
              font-size: 22px;
              font-weight: 600;
              margin: 0 0 20px;
              color: #111;
              border-bottom: 2px solid #005bbb;
              padding-bottom: 6px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 10px 12px;
              vertical-align: top;
            }
            th {
              background: #f4f7fb;
              font-weight: 600;
              text-align: left;
            }
            tr:nth-child(even) td {
              background: #fafafa;
            }
            /* hide unwanted totals */
            tfoot, .product-total, th.product-total, td.product-total { display:none !important; }
            .section-title {
              margin-top: 30px;
              font-size: 16px;
              font-weight: 600;
              color: #005bbb;
            }
          </style>
        `;

        w.document.open();
        w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Inquiry Quote</title>'+styles+'</head><body>');

        // Title
        w.document.write('<h1>Inquiry Details</h1>');

        // Order items table
        w.document.write(table.outerHTML);

        // Client details section
        if (client) {
          w.document.write('<div class="section-title">Client Details</div>');
          w.document.write(client.innerHTML);
        }

        w.document.write('</body></html>');
        w.document.close();

        w.focus();
        setTimeout(function(){ try { w.print(); } catch(e) {} }, 300);
      }

      document.addEventListener('click', function(e){
        var btn = e.target.closest('.rq-download-quote');
        if (!btn) return;
        e.preventDefault();
        openInquiryStyled();
      }, false);
    })();
    </script>
<?php
});






add_action('wp_footer', function () {
    if ( ! function_exists('is_order_received_page') || ! is_order_received_page() ) return; ?>
    <script>
    (function(){
      function openInquiryStyled(){
        var table  = document.querySelector('.woocommerce-table--order-details, .shop_table.order_details');
        var client = document.querySelector('.woocommerce-customer-details');
        if (!table) return;

        var w = window.open('', 'quote_print', 'width=900,height=900');
        if (!w) return;

        var styles = `
          <style>
            @page { margin: 15mm; }
            body {
              font-family: "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              font-size: 13px;
              line-height: 1.5;
              color: #333;
              margin: 0;
              padding: 20px;
              background: #fff;
            }
            .pdf-header {
              text-align: center;
              margin-bottom: 20px;
            }
            .pdf-header img {
              max-height: 60px;
            }
            h1 {
              font-size: 18px;
              font-weight: 600;
              margin: 10px 0;
              color: #222;
              border-bottom: 1px solid #ccc;
              padding-bottom: 4px;
              text-align: left;
            }
            .section-title {
              margin-top: 20px;
              font-size: 15px;
              font-weight: 600;
              color: #444;
              border-bottom: 1px solid #e0e0e0;
              padding-bottom: 3px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 12px;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 8px 10px;
              vertical-align: top;
            }
            th {
              background: #f7f7f7;
              font-weight: 600;
              text-align: left;
              font-size: 13px;
            }
            td {
              font-size: 13px;
            }
            tr:nth-child(even) td {
              background: #fafafa;
            }
            /* Hide unwanted totals */
            tfoot, .product-total, th.product-total, td.product-total { display:none !important; }
            .pdf-footer {
              margin-top: 40px;
              font-size: 12px;
              color: #666;
              text-align: center;
              border-top: 1px solid #ddd;
              padding-top: 10px;
            }
          </style>
        `;

        w.document.open();
        w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>Inquiry Quote</title>'+styles+'</head><body>');

        // ===== HEADER WITH LOGO =====
        w.document.write('<div class="pdf-header">');
        w.document.write('<img src="https://alispo.com/wp-content/uploads/2025/07/alispo.png" alt="Alispo Logo">');
        w.document.write('</div>');

        // Title
        w.document.write('<h1>Inquiry Details</h1>');

        // Order items table
        w.document.write(table.outerHTML);

        // Client details section
        if (client) {
          w.document.write('<div class="section-title">Client Details</div>');
          w.document.write(client.innerHTML);
        }

        // ===== FOOTER TEXT =====
        w.document.write('<div class="pdf-footer">');
        w.document.write('Copyright © 2025 Alispo International. All Rights Reserved.');
        w.document.write('</div>');

        w.document.write('</body></html>');
        w.document.close();

        w.focus();
        setTimeout(function(){ try { w.print(); } catch(e) {} }, 300);
      }

      document.addEventListener('click', function(e){
        var btn = e.target.closest('.rq-download-quote');
        if (!btn) return;
        e.preventDefault();
        openInquiryStyled();
      }, false);
    })();
    </script>
<?php
});






/**
 * Show Product SKU in Cart and Order Review (Thank You / Emails).
 */

/* === Add SKU in the Cart page === */
add_filter('woocommerce_cart_item_name', function ($name, $cart_item, $cart_item_key) {
    $product = $cart_item['data'];
    if ( $product && $product->get_sku() ) {
        $name .= '<br><small class="product-sku">SKU: ' . esc_html( $product->get_sku() ) . '</small>';
    }
    return $name;
}, 10, 3);

/* === Add SKU in the Order Details / Thank You page / Emails === */
add_filter('woocommerce_order_item_name', function ($name, $item, $is_visible) {
    $product = $item->get_product();
    if ( $product && $product->get_sku() ) {
        $name .= '<br><small class="product-sku">SKU: ' . esc_html( $product->get_sku() ) . '</small>';
    }
    return $name;
}, 10, 3);

/* === Optional: Small CSS tweak to make SKU look subtle === */
add_action('wp_head', function () {
    echo '<style>
      .product-sku {
        color:#555;
        font-size:12px;
        font-style:italic;
      }
    </style>';
});




/**
 * AJAX remove cart items on the cart page (no full reload)
 * - Calls WooCommerce wc-ajax=remove_from_cart
 * - Replaces only the cart table & totals with fresh HTML
 */
add_action('wp_enqueue_scripts', function () {
    if ( ! is_cart() ) return;

    // Ensure jQuery + Woo fragments are present
    wp_enqueue_script('jquery');
    wp_enqueue_script('wc-cart-fragments');

    // Inline JS (runs after wc-cart-fragments)
    $js = <<<JS
    jQuery(function($){
      // Delegate on the cart form remove links
      $(document).on('click', 'form.woocommerce-cart-form a.remove[data-cart_item_key]', function(e){
        e.preventDefault();

        var \$link = $(this);
        var key   = \$link.data('cart_item_key');

        if (!key) { window.location.href = \$link.attr('href'); return; }

        // Soft visual cue
        var \$row = \$link.closest('tr');
        \$row.css('opacity', .5);

        // 1) Remove item via Woo endpoint
        var endpoint = (typeof wc_cart_params !== 'undefined' ? wc_cart_params.wc_ajax_url : window.wc_ajax_url || '/')
                         .toString().replace('%%endpoint%%', 'remove_from_cart');

        $.post(endpoint, { cart_item_key: key })
          .done(function(){
            // 2) Pull the current page HTML, swap the cart form & totals only
            $.get(window.location.href).done(function(html){
              var \$html     = $($.parseHTML(html));
              var \$newForm  = \$html.find('form.woocommerce-cart-form');
              var \$newTotals= \$html.find('.cart_totals');

              var \$oldForm  = $('form.woocommerce-cart-form');
              var \$oldTotals= $('.cart_totals');

              if (\$newForm.length && \$oldForm.length)   { \$oldForm.replaceWith(\$newForm); }
              if (\$newTotals.length && \$oldTotals.length){ \$oldTotals.replaceWith(\$newTotals); }

              // Let Woo/Theme refresh any dependent fragments (mini-cart, etc.)
              $(document.body).trigger('updated_wc_div');
              $(document.body).trigger('wc_fragment_refresh');
            });
          })
          .fail(function(){
            // Fallback: normal navigation if AJAX fails
            window.location.href = \$link.attr('href');
          });
      });
    });
    JS;

    wp_add_inline_script('wc-cart-fragments', $js, 'after');
});











/* ---------- Mini-cart safe SKU handling ---------- */

/* Flag when the mini-cart is rendering */
add_action('woocommerce_before_mini_cart', function () { $GLOBALS['RQ_IN_MINICART'] = true; });
add_action('woocommerce_after_mini_cart',  function () { unset($GLOBALS['RQ_IN_MINICART']); });

/* Helper: are we on a page with a full table (cart/checkout/thank-you/account)? */
if (!function_exists('rq_is_order_table_context')) {
    function rq_is_order_table_context() {
        return ( is_cart()
            || is_checkout()
            || ( function_exists('is_order_received_page') && is_order_received_page() )
            || is_account_page()
        );
    }
}

/**
 * Clean up product name for mini-cart (strip any previous SKU HTML),
 * and only append our hidden marker on full table pages (never mini-cart).
 */
add_filter('woocommerce_cart_item_name', function ($name, $cart_item, $cart_item_key) {

    // Inside mini-cart: strip any SKU HTML/markers that were added earlier
    if ( !empty($GLOBALS['RQ_IN_MINICART']) ) {
        // remove <br><small class="product-sku">…</small> (raw and escaped)
        $name = preg_replace('#<br\s*/?>\s*<small[^>]*class=["\']product-sku["\'][^>]*>.*?</small>#i', '', $name);
        $name = preg_replace('#&lt;br\s*/?&gt;\s*&lt;small[^&]*class=&quot;product-sku&quot;[^&]*&gt;.*?&lt;/small&gt;#i', '', $name);
        // remove our hidden marker span (raw and escaped)
        $name = preg_replace('#<span[^>]*class=["\']rq-sku-marker["\'][^>]*>.*?</span>#i', '', $name);
        $name = preg_replace('#&lt;span[^&]*class=&quot;rq-sku-marker&quot;[^&]*&gt;.*?&lt;/span&gt;#i', '', $name);
        return $name;
    }

    // On full table pages, append only a hidden data marker (used to build the SKU column)
    if ( rq_is_order_table_context() ) {
        $product = isset($cart_item['data']) ? $cart_item['data'] : null;
        $sku     = ($product && is_object($product)) ? $product->get_sku() : '';
        if ( $sku && strpos($name, 'rq-sku-marker') === false ) {
            $name .= '<span class="rq-sku-marker" data-sku="' . esc_attr($sku) . '" style="display:none" aria-hidden="true"></span>';
        }
    }

    return $name;
}, 99, 3);

/* Also guard order items (thank-you/account): never add markers inside mini-cart render */
add_filter('woocommerce_order_item_name', function ($name, $item, $is_visible) {
    if ( !empty($GLOBALS['RQ_IN_MINICART']) ) {
        // strip any marker that slipped through
        $name = preg_replace('#<span[^>]*class=["\']rq-sku-marker["\'][^>]*>.*?</span>#i', '', $name);
        $name = preg_replace('#&lt;span[^&]*class=&quot;rq-sku-marker&quot;[^&]*&gt;.*?&lt;/span&gt;#i', '', $name);
        return $name;
    }
    if ( rq_is_order_table_context() ) {
        $product = $item->get_product();
        $sku     = ($product && is_object($product)) ? $product->get_sku() : '';
        if ( $sku && strpos($name, 'rq-sku-marker') === false ) {
            $name .= '<span class="rq-sku-marker" data-sku="' . esc_attr($sku) . '" style="display:none" aria-hidden="true"></span>';
        }
    }
    return $name;
}, 99, 3);


















// Limit mini-cart dropdown to viewport height with scroll
add_action('wp_head', function () {
    ?>
    <style>
      /* Base container: make content column layout so buttons stay visible */
      .widget_shopping_cart_content,
      .elementor-menu-cart__main,
      .woocommerce-mini-cart__container {
        display: flex;
        flex-direction: column;
        max-height: calc(100vh - 140px) !important; /* fits on screen */
        width: 100%;
      }

      /* The list of products should scroll */
      .widget_shopping_cart .cart_list,
      .woocommerce-mini-cart,
      .elementor-menu-cart__products {
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
        overscroll-behavior: contain;
        max-height: calc(100vh - 220px) !important; /* leaves room for header + footer in panel */
      }

      /* Keep subtotal + buttons fixed at the bottom of the panel */
      .woocommerce-mini-cart__total,
      .woocommerce-mini-cart__buttons,
      .elementor-menu-cart__subtotal,
      .elementor-menu-cart__footer-buttons {
        flex: 0 0 auto;
        background: #fff;
        position: sticky;
        bottom: 0;
        z-index: 1;
      }

      /* Nice scrollbar (optional) */
      .woocommerce-mini-cart::-webkit-scrollbar,
      .elementor-menu-cart__products::-webkit-scrollbar { width: 8px; }
      .woocommerce-mini-cart::-webkit-scrollbar-thumb,
      .elementor-menu-cart__products::-webkit-scrollbar-thumb { background:#c9c9c9; border-radius: 8px; }

      /* Small screens: slightly taller usable area */
      @media (max-width: 782px) {
        .widget_shopping_cart_content,
        .elementor-menu-cart__main,
        .woocommerce-mini-cart__container {
          max-height: calc(100vh - 100px) !important;
        }
        .widget_shopping_cart .cart_list,
        .woocommerce-mini-cart,
        .elementor-menu-cart__products {
          max-height: calc(100vh - 180px) !important;
        }
      }
    </style>
    <?php
});





// Improved mini-cart dropdown styling
add_action('wp_head', function () {
    ?>
    <style>
      /* Outer container: flex layout */
      .widget_shopping_cart_content,
      .elementor-menu-cart__main,
      .woocommerce-mini-cart__container {
        display: flex;
        flex-direction: column;
        max-height: calc(80vh - 180px) !important; /* push up from bottom */
        width: 380px !important; /* wider than default */
      }

      /* List of products scrolls */
      .widget_shopping_cart .cart_list,
      .woocommerce-mini-cart,
      .elementor-menu-cart__products {
        overflow-y: auto;
        -webkit-overflow-scrolling: touch;
        overscroll-behavior: contain;
        max-height: calc(100vh - 260px) !important; /* leave extra space for footer */
        padding-right: 6px; /* space for scrollbar */
      }

      /* Subtotal + buttons always visible */
      .woocommerce-mini-cart__total,
      .woocommerce-mini-cart__buttons,
      .elementor-menu-cart__subtotal,
      .elementor-menu-cart__footer-buttons {
        flex: 0 0 auto;
        background: #fff;
        position: sticky;
        bottom: 0;
        z-index: 2;
        padding-top: 20px;
        padding-bottom: 12px;
      }

      /* Nice scrollbar */
      .woocommerce-mini-cart::-webkit-scrollbar,
      .elementor-menu-cart__products::-webkit-scrollbar { width: 8px; }
      .woocommerce-mini-cart::-webkit-scrollbar-thumb,
      .elementor-menu-cart__products::-webkit-scrollbar-thumb { background:#1e73be; border-radius: 8px; }

      /* Mobile adjustments */
      @media (max-width: 782px) {
        .widget_shopping_cart_content,
        .elementor-menu-cart__main,
        .woocommerce-mini-cart__container {
          max-height: calc(100vh - 140px) !important;
          width: 92% !important; /* nearly full width on mobile */
          margin: 0 auto;
        }
        .widget_shopping_cart .cart_list,
        .woocommerce-mini-cart,
        .elementor-menu-cart__products {
          max-height: calc(100vh - 220px) !important;
        }
      }
    </style>
    <?php
});







/**
 * Disable Dashboard Notifications, Plugin Ads & Update Nags
 * Safe for Child Theme – Alispo International
 */

// 🔹 Disable Admin Notices from Plugins/Themes
add_action('admin_head', function () {
    remove_all_actions('admin_notices');
    remove_all_actions('all_admin_notices');
});

// 🔹 Disable “WordPress Update Available” notice
add_action('admin_menu', function () {
    remove_action('admin_notices', 'update_nag', 3);
});

// 🔹 Hide “Please rate this plugin” or “Upgrade to Pro” notices
add_action('admin_init', function () {
    // Hide all notices
    if (is_admin()) {
        remove_all_actions('user_admin_notices');
        remove_all_actions('network_admin_notices');
    }
});

// 🔹 Remove dashboard widgets (optional – keep only what matters)
add_action('wp_dashboard_setup', function () {
    remove_meta_box('dashboard_primary', 'dashboard', 'side');   // WordPress News
    remove_meta_box('dashboard_quick_press', 'dashboard', 'side');
    remove_meta_box('dashboard_activity', 'dashboard', 'normal');
    remove_meta_box('dashboard_right_now', 'dashboard', 'normal');
});

// 🔹 Remove “Try Gutenberg” or “Welcome” panels
remove_action('welcome_panel', 'wp_welcome_panel');

// 🔹 Disable plugin nag messages (like Elementor, Yoast, etc.)
add_action('in_admin_header', function () {
    remove_all_actions('admin_notices');
    remove_all_actions('all_admin_notices');
});

// 🔹 Optional: Hide admin bar updates dropdown
add_action('admin_bar_menu', function ($wp_admin_bar) {
    $wp_admin_bar->remove_node('updates');
}, 999);

// 🔹 Optional: Disable “Plugin Update Available” message on plugins page
add_filter('site_transient_update_plugins', function ($value) {
    if (isset($value) && is_object($value)) {
        $value->response = [];
    }
    return $value;
});




