<?php
defined( 'ABSPATH' ) || exit;

get_header( 'shop' );
?>

<div class="medova-shop-container full-width-shop">
    <div class="row medova-shop-wrap">
        
        <!-- Sidebar Column -->
        <div class="col-lg-4 col-xl-3">
            <aside class="sidebar-area shop-sidebar">
                <?php if ( is_active_sidebar( 'medova-woo-sidebar' ) ) {
                    dynamic_sidebar( 'medova-woo-sidebar' );
                } else {
                    do_action( 'woocommerce_sidebar' );
                } ?>
            </aside>
        </div>

        <!-- Products Column -->
        <div class="col-lg-8 col-xl-9">
            <?php
            /**
             * Hook: woocommerce_before_main_content.
             *
             * @hooked woocommerce_output_content_wrapper - 10
             * @hooked woocommerce_breadcrumb - 20
             */
            do_action( 'woocommerce_before_main_content' );

            if ( woocommerce_product_loop() ) {

                /**
                 * Hook: woocommerce_before_shop_loop.
                 *
                 * @hooked woocommerce_output_all_notices - 10
                 * @hooked woocommerce_result_count - 20
                 * @hooked woocommerce_catalog_ordering - 30
                 */
                do_action( 'woocommerce_before_shop_loop' );

                /**
                 * Products output (Medova custom hook)
                 */
                do_action( 'medova_woocommerce_product_content' );

                /**
                 * Hook: woocommerce_after_shop_loop.
                 *
                 * @hooked woocommerce_pagination - 10
                 */
                do_action( 'woocommerce_after_shop_loop' );

            } else {
                do_action( 'woocommerce_no_products_found' );
            }

            /**
             * Hook: woocommerce_after_main_content.
             *
             * @hooked woocommerce_output_content_wrapper_end - 10
             */
            do_action( 'woocommerce_after_main_content' );
            ?>
        </div><!-- End Products Column -->

    </div><!-- End Row -->
</div><!-- End Container -->

<?php get_footer( 'shop' ); ?>
